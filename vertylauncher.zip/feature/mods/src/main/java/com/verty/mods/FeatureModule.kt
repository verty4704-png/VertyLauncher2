package com.verty.mods

// Feature module entry point
// Placeholder for mods feature implementation
