package com.verty.auth

// Feature module entry point
// Placeholder for auth feature implementation
