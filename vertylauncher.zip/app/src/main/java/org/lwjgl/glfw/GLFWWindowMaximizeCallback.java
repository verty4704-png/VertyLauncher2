package org.lwjgl.glfw;

/**
 * Fake GLFWWindowMaximizeCallback for Android LWJGL bridge.
 */
public abstract class GLFWWindowMaximizeCallback {
    public abstract void invoke(long window, boolean maximized);
}
