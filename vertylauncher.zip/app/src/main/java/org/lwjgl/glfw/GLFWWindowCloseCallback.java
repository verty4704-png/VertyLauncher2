package org.lwjgl.glfw;

/**
 * Fake GLFWWindowCloseCallback for Android LWJGL bridge.
 */
public abstract class GLFWWindowCloseCallback {
    public abstract void invoke(long window);
}
