package org.lwjgl.glfw;

/**
 * Fake GLFWWindowRefreshCallback for Android LWJGL bridge.
 */
public abstract class GLFWWindowRefreshCallback {
    public abstract void invoke(long window);
}
