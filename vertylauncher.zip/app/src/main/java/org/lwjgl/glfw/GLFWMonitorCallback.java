package org.lwjgl.glfw;

/**
 * Fake GLFWMonitorCallback for Android LWJGL bridge.
 */
public abstract class GLFWMonitorCallback {
    public abstract void invoke(long monitor, int event);
}
