package org.lwjgl.glfw;

/**
 * Fake GLFWScrollCallback for Android LWJGL bridge.
 */
public abstract class GLFWScrollCallback {
    public abstract void invoke(long window, double xoffset, double yoffset);
}
