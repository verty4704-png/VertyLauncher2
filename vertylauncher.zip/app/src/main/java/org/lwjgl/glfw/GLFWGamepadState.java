package org.lwjgl.glfw;

public class GLFWGamepadState {
    public final byte[] buttons = new byte[15];
    public final float[] axes = new float[6];
}
