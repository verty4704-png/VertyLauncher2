package org.lwjgl.glfw;

/**
 * Fake GLFWWindowPosCallback for Android LWJGL bridge.
 */
public abstract class GLFWWindowPosCallback {
    public abstract void invoke(long window, int xpos, int ypos);
}
