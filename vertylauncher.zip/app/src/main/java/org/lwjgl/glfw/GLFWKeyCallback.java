package org.lwjgl.glfw;

/**
 * Fake GLFWKeyCallback for Android LWJGL bridge.
 */
public abstract class GLFWKeyCallback {
    public abstract void invoke(long window, int key, int scancode, int action, int mods);
}
