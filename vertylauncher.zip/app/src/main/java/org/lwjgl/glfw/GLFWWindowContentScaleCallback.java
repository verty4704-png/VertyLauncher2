package org.lwjgl.glfw;

/**
 * Fake GLFWWindowContentScaleCallback for Android LWJGL bridge.
 */
public abstract class GLFWWindowContentScaleCallback {
    public abstract void invoke(long window, float xscale, float yscale);
}
