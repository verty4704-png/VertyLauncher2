package org.lwjgl.glfw;

/**
 * Fake GLFWWindowSizeCallback for Android LWJGL bridge.
 */
public abstract class GLFWWindowSizeCallback {
    public abstract void invoke(long window, int width, int height);
}
