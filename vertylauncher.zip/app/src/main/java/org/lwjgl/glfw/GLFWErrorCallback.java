package org.lwjgl.glfw;

/**
 * Fake GLFWErrorCallback for Android LWJGL bridge.
 */
public abstract class GLFWErrorCallback {
    public abstract void invoke(int error, long description);
}
