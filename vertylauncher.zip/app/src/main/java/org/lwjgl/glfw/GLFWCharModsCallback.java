package org.lwjgl.glfw;

/**
 * Fake GLFWCharModsCallback for Android LWJGL bridge.
 */
public abstract class GLFWCharModsCallback {
    public abstract void invoke(long window, int codepoint, int mods);
}
