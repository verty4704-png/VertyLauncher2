package org.lwjgl.glfw;

/**
 * Fake GLFWWindowIconifyCallback for Android LWJGL bridge.
 */
public abstract class GLFWWindowIconifyCallback {
    public abstract void invoke(long window, boolean iconified);
}
