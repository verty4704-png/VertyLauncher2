package org.lwjgl.glfw;

/**
 * Fake GLFWDropCallback for Android LWJGL bridge.
 */
public abstract class GLFWDropCallback {
    public abstract void invoke(long window, int count, long names);
}
