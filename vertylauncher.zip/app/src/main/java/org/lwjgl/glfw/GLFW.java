package org.lwjgl.glfw;

/**
 * Fake GLFW class for Android.
 * Redirects window/input calls to Android SurfaceView.
 */
public class GLFW {
    public static final int GLFW_VERSION_MAJOR = 3;
    public static final int GLFW_VERSION_MINOR = 3;
    public static final int GLFW_VERSION_REVISION = 2;

    public static final int GLFW_TRUE = 1;
    public static final int GLFW_FALSE = 0;
    public static final int GLFW_RELEASE = 0;
    public static final int GLFW_PRESS = 1;
    public static final int GLFW_REPEAT = 2;

    public static final int GLFW_KEY_UNKNOWN = -1;
    public static final int GLFW_KEY_SPACE = 32;
    public static final int GLFW_KEY_APOSTROPHE = 39;
    public static final int GLFW_KEY_COMMA = 44;
    public static final int GLFW_KEY_MINUS = 45;
    public static final int GLFW_KEY_PERIOD = 46;
    public static final int GLFW_KEY_SLASH = 47;
    public static final int GLFW_KEY_0 = 48;
    public static final int GLFW_KEY_1 = 49;
    public static final int GLFW_KEY_2 = 50;
    public static final int GLFW_KEY_3 = 51;
    public static final int GLFW_KEY_4 = 52;
    public static final int GLFW_KEY_5 = 53;
    public static final int GLFW_KEY_6 = 54;
    public static final int GLFW_KEY_7 = 55;
    public static final int GLFW_KEY_8 = 56;
    public static final int GLFW_KEY_9 = 57;
    public static final int GLFW_KEY_SEMICOLON = 59;
    public static final int GLFW_KEY_EQUAL = 61;
    public static final int GLFW_KEY_A = 65;
    public static final int GLFW_KEY_B = 66;
    public static final int GLFW_KEY_C = 67;
    public static final int GLFW_KEY_D = 68;
    public static final int GLFW_KEY_E = 69;
    public static final int GLFW_KEY_F = 70;
    public static final int GLFW_KEY_G = 71;
    public static final int GLFW_KEY_H = 72;
    public static final int GLFW_KEY_I = 73;
    public static final int GLFW_KEY_J = 74;
    public static final int GLFW_KEY_K = 75;
    public static final int GLFW_KEY_L = 76;
    public static final int GLFW_KEY_M = 77;
    public static final int GLFW_KEY_N = 78;
    public static final int GLFW_KEY_O = 79;
    public static final int GLFW_KEY_P = 80;
    public static final int GLFW_KEY_Q = 81;
    public static final int GLFW_KEY_R = 82;
    public static final int GLFW_KEY_S = 83;
    public static final int GLFW_KEY_T = 84;
    public static final int GLFW_KEY_U = 85;
    public static final int GLFW_KEY_V = 86;
    public static final int GLFW_KEY_W = 87;
    public static final int GLFW_KEY_X = 88;
    public static final int GLFW_KEY_Y = 89;
    public static final int GLFW_KEY_Z = 90;
    public static final int GLFW_KEY_LEFT_BRACKET = 91;
    public static final int GLFW_KEY_BACKSLASH = 92;
    public static final int GLFW_KEY_RIGHT_BRACKET = 93;
    public static final int GLFW_KEY_GRAVE_ACCENT = 96;
    public static final int GLFW_KEY_WORLD_1 = 161;
    public static final int GLFW_KEY_WORLD_2 = 162;
    public static final int GLFW_KEY_ESCAPE = 256;
    public static final int GLFW_KEY_ENTER = 257;
    public static final int GLFW_KEY_TAB = 258;
    public static final int GLFW_KEY_BACKSPACE = 259;
    public static final int GLFW_KEY_INSERT = 260;
    public static final int GLFW_KEY_DELETE = 261;
    public static final int GLFW_KEY_RIGHT = 262;
    public static final int GLFW_KEY_LEFT = 263;
    public static final int GLFW_KEY_DOWN = 264;
    public static final int GLFW_KEY_UP = 265;
    public static final int GLFW_KEY_PAGE_UP = 266;
    public static final int GLFW_KEY_PAGE_DOWN = 267;
    public static final int GLFW_KEY_HOME = 268;
    public static final int GLFW_KEY_END = 269;
    public static final int GLFW_KEY_CAPS_LOCK = 280;
    public static final int GLFW_KEY_SCROLL_LOCK = 281;
    public static final int GLFW_KEY_NUM_LOCK = 282;
    public static final int GLFW_KEY_PRINT_SCREEN = 283;
    public static final int GLFW_KEY_PAUSE = 284;
    public static final int GLFW_KEY_F1 = 290;
    public static final int GLFW_KEY_F2 = 291;
    public static final int GLFW_KEY_F3 = 292;
    public static final int GLFW_KEY_F4 = 293;
    public static final int GLFW_KEY_F5 = 294;
    public static final int GLFW_KEY_F6 = 295;
    public static final int GLFW_KEY_F7 = 296;
    public static final int GLFW_KEY_F8 = 297;
    public static final int GLFW_KEY_F9 = 298;
    public static final int GLFW_KEY_F10 = 299;
    public static final int GLFW_KEY_F11 = 300;
    public static final int GLFW_KEY_F12 = 301;
    public static final int GLFW_KEY_F13 = 302;
    public static final int GLFW_KEY_F14 = 303;
    public static final int GLFW_KEY_F15 = 304;
    public static final int GLFW_KEY_F16 = 305;
    public static final int GLFW_KEY_F17 = 306;
    public static final int GLFW_KEY_F18 = 307;
    public static final int GLFW_KEY_F19 = 308;
    public static final int GLFW_KEY_F20 = 309;
    public static final int GLFW_KEY_F21 = 310;
    public static final int GLFW_KEY_F22 = 311;
    public static final int GLFW_KEY_F23 = 312;
    public static final int GLFW_KEY_F24 = 313;
    public static final int GLFW_KEY_F25 = 314;
    public static final int GLFW_KEY_KP_0 = 320;
    public static final int GLFW_KEY_KP_1 = 321;
    public static final int GLFW_KEY_KP_2 = 322;
    public static final int GLFW_KEY_KP_3 = 323;
    public static final int GLFW_KEY_KP_4 = 324;
    public static final int GLFW_KEY_KP_5 = 325;
    public static final int GLFW_KEY_KP_6 = 326;
    public static final int GLFW_KEY_KP_7 = 327;
    public static final int GLFW_KEY_KP_8 = 328;
    public static final int GLFW_KEY_KP_9 = 329;
    public static final int GLFW_KEY_KP_DECIMAL = 330;
    public static final int GLFW_KEY_KP_DIVIDE = 331;
    public static final int GLFW_KEY_KP_MULTIPLY = 332;
    public static final int GLFW_KEY_KP_SUBTRACT = 333;
    public static final int GLFW_KEY_KP_ADD = 334;
    public static final int GLFW_KEY_KP_ENTER = 335;
    public static final int GLFW_KEY_KP_EQUAL = 336;
    public static final int GLFW_KEY_LEFT_SHIFT = 340;
    public static final int GLFW_KEY_LEFT_CONTROL = 341;
    public static final int GLFW_KEY_LEFT_ALT = 342;
    public static final int GLFW_KEY_LEFT_SUPER = 343;
    public static final int GLFW_KEY_RIGHT_SHIFT = 344;
    public static final int GLFW_KEY_RIGHT_CONTROL = 345;
    public static final int GLFW_KEY_RIGHT_ALT = 346;
    public static final int GLFW_KEY_RIGHT_SUPER = 347;
    public static final int GLFW_KEY_MENU = 348;
    public static final int GLFW_KEY_LAST = GLFW_KEY_MENU;

    public static final int GLFW_MOUSE_BUTTON_1 = 0;
    public static final int GLFW_MOUSE_BUTTON_2 = 1;
    public static final int GLFW_MOUSE_BUTTON_3 = 2;
    public static final int GLFW_MOUSE_BUTTON_4 = 3;
    public static final int GLFW_MOUSE_BUTTON_5 = 4;
    public static final int GLFW_MOUSE_BUTTON_6 = 5;
    public static final int GLFW_MOUSE_BUTTON_7 = 6;
    public static final int GLFW_MOUSE_BUTTON_8 = 7;
    public static final int GLFW_MOUSE_BUTTON_LAST = GLFW_MOUSE_BUTTON_8;
    public static final int GLFW_MOUSE_BUTTON_LEFT = GLFW_MOUSE_BUTTON_1;
    public static final int GLFW_MOUSE_BUTTON_RIGHT = GLFW_MOUSE_BUTTON_2;
    public static final int GLFW_MOUSE_BUTTON_MIDDLE = GLFW_MOUSE_BUTTON_3;

    public static final int GLFW_CURSOR = 0x00033001;
    public static final int GLFW_STICKY_KEYS = 0x00033002;
    public static final int GLFW_STICKY_MOUSE_BUTTONS = 0x00033003;
    public static final int GLFW_CURSOR_NORMAL = 0x00034001;
    public static final int GLFW_CURSOR_HIDDEN = 0x00034002;
    public static final int GLFW_CURSOR_DISABLED = 0x00034003;

    public static final int GLFW_RESIZABLE = 0x00020003;
    public static final int GLFW_VISIBLE = 0x00020004;
    public static final int GLFW_DECORATED = 0x00020005;
    public static final int GLFW_FOCUSED = 0x00020001;
    public static final int GLFW_ICONIFIED = 0x00020002;
    public static final int GLFW_AUTO_ICONIFY = 0x00020006;
    public static final int GLFW_FLOATING = 0x00020007;
    public static final int GLFW_MAXIMIZED = 0x00020008;
    public static final int GLFW_RED_BITS = 0x00021001;
    public static final int GLFW_GREEN_BITS = 0x00021002;
    public static final int GLFW_BLUE_BITS = 0x00021003;
    public static final int GLFW_ALPHA_BITS = 0x00021004;
    public static final int GLFW_DEPTH_BITS = 0x00021005;
    public static final int GLFW_STENCIL_BITS = 0x00021006;
    public static final int GLFW_REFRESH_RATE = 0x0002100F;
    public static final int GLFW_CLIENT_API = 0x00022001;
    public static final int GLFW_CONTEXT_VERSION_MAJOR = 0x00022002;
    public static final int GLFW_CONTEXT_VERSION_MINOR = 0x00022003;
    public static final int GLFW_OPENGL_FORWARD_COMPAT = 0x00022006;
    public static final int GLFW_OPENGL_PROFILE = 0x00022007;
    public static final int GLFW_OPENGL_API = 0x00030001;
    public static final int GLFW_OPENGL_ES_API = 0x00030002;
    public static final int GLFW_OPENGL_CORE_PROFILE = 0x00032001;
    public static final int GLFW_OPENGL_COMPAT_PROFILE = 0x00032002;
    public static final int GLFW_OPENGL_ANY_PROFILE = 0;
    public static final int GLFW_CONTEXT_CREATION_API = 0x0002200B;
    public static final int GLFW_NATIVE_CONTEXT_API = 0x00036001;
    public static final int GLFW_EGL_CONTEXT_API = 0x00036002;
    public static final int GLFW_OSMESA_CONTEXT_API = 0x00036003;
    public static final int GLFW_CONTEXT_NO_ERROR = 0x0002200A;
    public static final int GLFW_CONTEXT_ROBUSTNESS = 0x00022005;
    public static final int GLFW_NO_ROBUSTNESS = 0;
    public static final int GLFW_NO_RESET_NOTIFICATION = 0x00031001;
    public static final int GLFW_LOSE_CONTEXT_ON_RESET = 0x00031002;

    public static final int GLFW_CONNECTED = 0x00040001;
    public static final int GLFW_DISCONNECTED = 0x00040002;

    public static final int GLFW_JOYSTICK_HAT_BUTTONS = 0x00050001;
    public static final int GLFW_COCOA_CHDIR_RESOURCES = 0x00051001;
    public static final int GLFW_COCOA_MENUBAR = 0x00051002;

    public static final int GLFW_DONT_CARE = -1;

    static {
        System.loadLibrary("verty_lwjgl");
    }

    // === Initialization ===
    public static native boolean glfwInit();
    public static native void glfwTerminate();
    public static native void glfwInitHint(int hint, int value);
    public static native void glfwGetVersion(int[] major, int[] minor, int[] rev);
    public static native String glfwGetVersionString();

    // === Window ===
    public static native long glfwCreateWindow(int width, int height, String title, long monitor, long share);
    public static native void glfwDestroyWindow(long window);
    public static native boolean glfwWindowShouldClose(long window);
    public static native void glfwSetWindowShouldClose(long window, boolean value);
    public static native void glfwSetWindowTitle(long window, String title);
    public static native void glfwGetWindowPos(long window, int[] xpos, int[] ypos);
    public static native void glfwSetWindowPos(long window, int xpos, int ypos);
    public static native void glfwGetWindowSize(long window, int[] width, int[] height);
    public static native void glfwSetWindowSize(long window, int width, int height);
    public static native void glfwSetWindowSizeLimits(long window, int minwidth, int minheight, int maxwidth, int maxheight);
    public static native void glfwSetWindowAspectRatio(long window, int numer, int denom);
    public static native void glfwGetFramebufferSize(long window, int[] width, int[] height);
    public static native void glfwGetWindowFrameSize(long window, int[] left, int[] top, int[] right, int[] bottom);
    public static native void glfwGetWindowContentScale(long window, float[] xscale, float[] yscale);
    public static native float glfwGetWindowOpacity(long window);
    public static native void glfwSetWindowOpacity(long window, float opacity);
    public static native void glfwIconifyWindow(long window);
    public static native void glfwRestoreWindow(long window);
    public static native void glfwMaximizeWindow(long window);
    public static native void glfwShowWindow(long window);
    public static native void glfwHideWindow(long window);
    public static native void glfwFocusWindow(long window);
    public static native void glfwRequestWindowAttention(long window);
    public static native long glfwGetWindowMonitor(long window);
    public static native void glfwSetWindowMonitor(long window, long monitor, int xpos, int ypos, int width, int height, int refreshRate);
    public static native int glfwGetWindowAttrib(long window, int attrib);
    public static native void glfwSetWindowAttrib(long window, int attrib, int value);
    public static native void glfwSetWindowUserPointer(long window, long pointer);
    public static native long glfwGetWindowUserPointer(long window);
    public static native void glfwSetWindowPosCallback(long window, GLFWWindowPosCallback callback);
    public static native void glfwSetWindowSizeCallback(long window, GLFWWindowSizeCallback callback);
    public static native void glfwSetWindowCloseCallback(long window, GLFWWindowCloseCallback callback);
    public static native void glfwSetWindowRefreshCallback(long window, GLFWWindowRefreshCallback callback);
    public static native void glfwSetWindowFocusCallback(long window, GLFWWindowFocusCallback callback);
    public static native void glfwSetWindowIconifyCallback(long window, GLFWWindowIconifyCallback callback);
    public static native void glfwSetWindowMaximizeCallback(long window, GLFWWindowMaximizeCallback callback);
    public static native void glfwSetFramebufferSizeCallback(long window, GLFWFramebufferSizeCallback callback);
    public static native void glfwSetWindowContentScaleCallback(long window, GLFWWindowContentScaleCallback callback);

    // === Context ===
    public static native void glfwMakeContextCurrent(long window);
    public static native long glfwGetCurrentContext();
    public static native void glfwSwapInterval(int interval);
    public static native void glfwSwapBuffers(long window);

    // === Input ===
    public static native boolean glfwGetInputMode(long window, int mode);
    public static native void glfwSetInputMode(long window, int mode, int value);
    public static native int glfwGetKey(long window, int key);
    public static native int glfwGetMouseButton(long window, int button);
    public static native void glfwGetCursorPos(long window, double[] xpos, double[] ypos);
    public static native void glfwSetCursorPos(long window, double xpos, double ypos);
    public static native void glfwSetKeyCallback(long window, GLFWKeyCallback callback);
    public static native void glfwSetCharCallback(long window, GLFWCharCallback callback);
    public static native void glfwSetCharModsCallback(long window, GLFWCharModsCallback callback);
    public static native void glfwSetMouseButtonCallback(long window, GLFWMouseButtonCallback callback);
    public static native void glfwSetCursorPosCallback(long window, GLFWCursorPosCallback callback);
    public static native void glfwSetCursorEnterCallback(long window, GLFWCursorEnterCallback callback);
    public static native void glfwSetScrollCallback(long window, GLFWScrollCallback callback);
    public static native void glfwSetDropCallback(long window, GLFWDropCallback callback);
    public static native int glfwJoystickPresent(int jid);
    public static native float[] glfwGetJoystickAxes(int jid, int[] count);
    public static native byte[] glfwGetJoystickButtons(int jid, int[] count);
    public static native String glfwGetJoystickName(int jid);
    public static native String glfwGetJoystickGUID(int jid);
    public static native void glfwSetJoystickCallback(GLFWJoystickCallback callback);
    public static native int glfwUpdateGamepadMappings(String string);
    public static native boolean glfwGetGamepadState(int jid, GLFWGamepadState state);
    public static native void glfwSetClipboardString(long window, String string);
    public static native String glfwGetClipboardString(long window);
    public static native double glfwGetTime();
    public static native void glfwSetTime(double time);
    public static native double glfwGetTimerValue();
    public static native double glfwGetTimerFrequency();

    // === Events ===
    public static native void glfwPollEvents();
    public static native void glfwWaitEvents();
    public static native void glfwWaitEventsTimeout(double timeout);
    public static native void glfwPostEmptyEvent();

    // === Monitor ===
    public static native long[] glfwGetMonitors(int[] count);
    public static native long glfwGetPrimaryMonitor();
    public static native void glfwGetMonitorPos(long monitor, int[] xpos, int[] ypos);
    public static native void glfwGetMonitorWorkarea(long monitor, int[] xpos, int[] ypos, int[] width, int[] height);
    public static native void glfwGetMonitorPhysicalSize(long monitor, int[] widthMM, int[] heightMM);
    public static native void glfwGetMonitorContentScale(long monitor, float[] xscale, float[] yscale);
    public static native String glfwGetMonitorName(long monitor);
    public static native void glfwSetMonitorCallback(GLFWMonitorCallback callback);
    public static native int[] glfwGetVideoModes(long monitor, int[] count);
    public static native int glfwGetVideoMode(long monitor);
    public static native void glfwSetGamma(long monitor, float gamma);
    public static native int glfwGetGammaRamp(long monitor);
    public static native void glfwSetGammaRamp(long monitor, int ramp);

    // === Error ===
    public static native int glfwGetError(String[] description);
    public static native void glfwSetErrorCallback(GLFWErrorCallback callback);

    // === Vulkan ===
    public static native int glfwVulkanSupported();
    public static native String[] glfwGetRequiredInstanceExtensions(int[] count);
    public static native long glfwGetInstanceProcAddress(long instance, String procname);
    public static native int glfwGetPhysicalDevicePresentationSupport(long instance, long device, int queuefamily);
    public static native long glfwCreateWindowSurface(long instance, long window, long allocator, long surface);

    // === Hints ===
    public static native void glfwDefaultWindowHints();
    public static native void glfwWindowHint(int hint, int value);
    public static native void glfwWindowHintString(int hint, String value);
}
