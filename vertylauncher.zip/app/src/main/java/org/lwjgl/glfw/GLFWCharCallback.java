package org.lwjgl.glfw;

/**
 * Fake GLFWCharCallback for Android LWJGL bridge.
 */
public abstract class GLFWCharCallback {
    public abstract void invoke(long window, int codepoint);
}
