package org.lwjgl.glfw;

/**
 * Fake GLFWCursorPosCallback for Android LWJGL bridge.
 */
public abstract class GLFWCursorPosCallback {
    public abstract void invoke(long window, double xpos, double ypos);
}
