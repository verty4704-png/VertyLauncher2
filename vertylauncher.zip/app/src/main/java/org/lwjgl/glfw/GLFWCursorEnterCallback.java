package org.lwjgl.glfw;

/**
 * Fake GLFWCursorEnterCallback for Android LWJGL bridge.
 */
public abstract class GLFWCursorEnterCallback {
    public abstract void invoke(long window, boolean entered);
}
