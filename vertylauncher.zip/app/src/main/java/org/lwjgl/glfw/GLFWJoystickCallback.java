package org.lwjgl.glfw;

/**
 * Fake GLFWJoystickCallback for Android LWJGL bridge.
 */
public abstract class GLFWJoystickCallback {
    public abstract void invoke(int jid, int event);
}
