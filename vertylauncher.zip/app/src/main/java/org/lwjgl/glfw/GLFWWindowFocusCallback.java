package org.lwjgl.glfw;

/**
 * Fake GLFWWindowFocusCallback for Android LWJGL bridge.
 */
public abstract class GLFWWindowFocusCallback {
    public abstract void invoke(long window, boolean focused);
}
