package org.lwjgl.glfw;

/**
 * Fake GLFWMouseButtonCallback for Android LWJGL bridge.
 */
public abstract class GLFWMouseButtonCallback {
    public abstract void invoke(long window, int button, int action, int mods);
}
