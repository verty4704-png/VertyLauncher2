package org.lwjgl.glfw;

/**
 * Fake GLFWFramebufferSizeCallback for Android LWJGL bridge.
 */
public abstract class GLFWFramebufferSizeCallback {
    public abstract void invoke(long window, int width, int height);
}
