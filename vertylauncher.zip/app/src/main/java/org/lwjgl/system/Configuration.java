package org.lwjgl.system;

public class Configuration {
    public static final Configuration OPENGL_EXPLICIT_INIT = new Configuration();
    public static final Configuration OPENGL_CONTEXT_API = new Configuration();
    public static final Configuration OPENGL_CONTEXT_VERSION_MAJOR = new Configuration();
    public static final Configuration OPENGL_CONTEXT_VERSION_MINOR = new Configuration();
    public static final Configuration OPENGL_FORWARD_COMPAT = new Configuration();
    public static final Configuration OPENGL_PROFILE = new Configuration();
    public static final Configuration OPENGL_DEBUG = new Configuration();
    public static final Configuration OPENGL_MAXVERSION_MAJOR = new Configuration();
    public static final Configuration OPENGL_MAXVERSION_MINOR = new Configuration();

    private Object value;

    public void set(Object value) {
        this.value = value;
    }

    public Object get() {
        return value;
    }

    public int getInt(int defaultValue) {
        return value instanceof Number ? ((Number) value).intValue() : defaultValue;
    }

    public boolean getBoolean(boolean defaultValue) {
        return value instanceof Boolean ? (Boolean) value : defaultValue;
    }
}
