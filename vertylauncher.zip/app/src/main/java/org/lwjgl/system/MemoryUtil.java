package org.lwjgl.system;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class MemoryUtil {
    public static ByteBuffer memAlloc(int size) {
        return ByteBuffer.allocateDirect(size).order(ByteOrder.nativeOrder());
    }

    public static void memFree(ByteBuffer buffer) {
        // Direct buffers are GC'd automatically
    }

    public static long memAddress(ByteBuffer buffer) {
        // In real implementation, would use JNI to get native address
        return 0;
    }

    public static ByteBuffer memByteBuffer(long address, int capacity) {
        return ByteBuffer.allocateDirect(capacity).order(ByteOrder.nativeOrder());
    }
}
