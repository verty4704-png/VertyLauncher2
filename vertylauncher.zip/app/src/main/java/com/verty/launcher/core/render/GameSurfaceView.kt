package com.verty.launcher.core.render

import android.content.Context
import android.opengl.GLSurfaceView
import android.util.AttributeSet
import android.view.MotionEvent
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Android SurfaceView that acts as the "window" for Minecraft.
 * 
 * This is what Minecraft sees as its GLFW window.
 * Touch events are converted to mouse/keyboard input.
 */
class GameSurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs) {

    private var renderer: GameRenderer? = null
    private var touchHandler: TouchInputHandler? = null

    init {
        // Use OpenGL ES 3.2
        setEGLContextClientVersion(3)

        // Preserve EGL context when paused (faster resume)
        preserveEGLContextOnPause = true

        // Set renderer
        renderer = GameRenderer()
        setRenderer(renderer)

        // Touch input handler
        touchHandler = TouchInputHandler(context)

        // Render continuously (Minecraft needs this)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        touchHandler?.onTouchEvent(event)
        return true
    }

    fun injectMouseMove(x: Float, y: Float) {
        // Called from JNI when Minecraft moves mouse
        // No-op on Android — we control input from touch
    }

    fun injectMouseButton(button: Int, action: Int) {
        // Called from JNI when Minecraft clicks
        // No-op on Android
    }

    fun getNativeWindowHandle(): Long {
        // Return a fake window handle for GLFW
        // Real implementation would return EGLSurface pointer
        return hashCode().toLong()
    }

    inner class GameRenderer : GLSurfaceView.Renderer {
        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            // Initialize OpenGL ES context
            // This is where Minecraft would call GL11.glClear, etc.
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            // Notify Minecraft of window resize
            // Call GLFW framebuffer size callback
        }

        override fun onDrawFrame(gl: GL10?) {
            // Minecraft renders here
            // This is called continuously by GLSurfaceView
        }
    }
}
