package com.verty.launcher.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class MinecraftInstance(
    val id: String,
    val name: String,
    val version: String,
    val loader: ModLoader,
    val loaderVersion: String? = null,
    val javaVersion: Int = 17,
    val jvmArgs: List<String> = emptyList(),
    val gameArgs: List<String> = emptyList(),
    val maxMemoryMb: Int = 2048,
    val minMemoryMb: Int = 512,
    val resolution: Resolution = Resolution(1280, 720),
    val fullscreen: Boolean = false,
    val renderer: Renderer = Renderer.OPENGL,
    val shaderPack: String? = null,
    val modList: List<ModEntry> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val lastPlayed: Long? = null,
    val playCount: Int = 0,
    val totalPlayTime: Long = 0,
    val iconPath: String? = null,
    val isFavorite: Boolean = false
)

@Serializable
enum class ModLoader {
    VANILLA, FABRIC, FORGE, NEOFORGE, QUILT
}

@Serializable
enum class Renderer {
    OPENGL, VULKAN, SOFTWARE
}

@Serializable
data class Resolution(val width: Int, val height: Int)

@Serializable
data class ModEntry(
    val id: String,
    val name: String,
    val version: String,
    val fileName: String,
    val source: ModSource,
    val isEnabled: Boolean = true,
    val dependencies: List<String> = emptyList()
)

@Serializable
enum class ModSource {
    CURSEFORGE, MODRINTH, LOCAL, BUILT_IN
}
