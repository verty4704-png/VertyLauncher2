package com.verty.launcher.core.security

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TokenManager @Inject constructor(
    private val secureStorage: SecureStorage
) {
    companion object {
        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_EXPIRES_AT = "expires_at"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USERNAME = "username"
    }

    private val _authState = MutableStateFlow<AuthState>(AuthState.Unauthenticated)
    val authState: Flow<AuthState> = _authState.asStateFlow()

    val isAuthenticated: Flow<Boolean> = authState.map { it is AuthState.Authenticated }

    suspend fun saveTokens(accessToken: String, refreshToken: String, expiresIn: Long, userId: String, username: String) {
        val expiresAt = System.currentTimeMillis() + (expiresIn * 1000)
        secureStorage.store(KEY_ACCESS_TOKEN, accessToken)
        secureStorage.store(KEY_REFRESH_TOKEN, refreshToken)
        secureStorage.store(KEY_EXPIRES_AT, expiresAt.toString())
        secureStorage.store(KEY_USER_ID, userId)
        secureStorage.store(KEY_USERNAME, username)
        _authState.value = AuthState.Authenticated(userId, username)
    }

    suspend fun getAccessToken(): String? = secureStorage.retrieve(KEY_ACCESS_TOKEN)

    suspend fun getRefreshToken(): String? = secureStorage.retrieve(KEY_REFRESH_TOKEN)

    suspend fun isTokenExpired(): Boolean {
        val expiresAt = secureStorage.retrieve(KEY_EXPIRES_AT)?.toLongOrNull() ?: return true
        return System.currentTimeMillis() >= expiresAt - 300_000 // 5 min buffer
    }

    suspend fun clearTokens() {
        secureStorage.remove(KEY_ACCESS_TOKEN)
        secureStorage.remove(KEY_REFRESH_TOKEN)
        secureStorage.remove(KEY_EXPIRES_AT)
        secureStorage.remove(KEY_USER_ID)
        secureStorage.remove(KEY_USERNAME)
        _authState.value = AuthState.Unauthenticated
    }

    suspend fun initialize() {
        val token = secureStorage.retrieve(KEY_ACCESS_TOKEN)
        val userId = secureStorage.retrieve(KEY_USER_ID)
        val username = secureStorage.retrieve(KEY_USERNAME)
        if (token != null && userId != null) {
            _authState.value = AuthState.Authenticated(userId, username ?: "")
        } else {
            _authState.value = AuthState.Unauthenticated
        }
    }

    sealed class AuthState {
        object Unauthenticated : AuthState()
        data class Authenticated(val userId: String, val username: String) : AuthState()
    }
}
