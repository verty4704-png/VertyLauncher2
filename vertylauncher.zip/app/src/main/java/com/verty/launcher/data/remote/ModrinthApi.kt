package com.verty.launcher.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ModrinthApi {
    @GET("v2/search")
    suspend fun searchMods(
        @Query("query") query: String = "",
        @Query("facets") facets: List<String>? = null,
        @Query("offset") offset: Int = 0,
        @Query("limit") limit: Int = 20
    ): ModrinthSearchResponse

    @GET("v2/project/{id}")
    suspend fun getProject(@Path("id") id: String): ModrinthProject

    @GET("v2/project/{id}/version")
    suspend fun getProjectVersions(
        @Path("id") id: String,
        @Query("loaders") loaders: String? = null,
        @Query("game_versions") gameVersions: String? = null
    ): List<ModrinthVersion>

    @GET("v2/version/{id}")
    suspend fun getVersion(@Path("id") id: String): ModrinthVersion
}

@Serializable
data class ModrinthSearchResponse(
    val hits: List<ModrinthHit>,
    val offset: Int,
    val limit: Int,
    val totalHits: Int
)

@Serializable
data class ModrinthHit(
    val slug: String,
    val title: String,
    val description: String,
    val categories: List<String>,
    val clientSide: String,
    val serverSide: String,
    val projectType: String,
    val downloads: Int,
    val iconUrl: String? = null,
    val projectId: String,
    val author: String,
    val versions: List<String>,
    val follows: Int,
    val dateCreated: String,
    val dateModified: String,
    val latestVersion: String,
    val license: String,
    val gallery: List<String>
)

@Serializable
data class ModrinthProject(
    val id: String,
    val slug: String,
    val title: String,
    val description: String,
    val body: String? = null,
    val published: String,
    val updated: String,
    val status: String,
    val license: ModrinthLicense,
    val downloads: Int,
    val followers: Int,
    val categories: List<String>,
    val versions: List<String>,
    val iconUrl: String? = null,
    val clientSide: String,
    val serverSide: String,
    val sourceUrl: String? = null,
    val issuesUrl: String? = null,
    val wikiUrl: String? = null,
    val discordUrl: String? = null,
    val donationUrls: List<ModrinthDonationUrl> = emptyList()
)

@Serializable
data class ModrinthLicense(
    val id: String,
    val name: String,
    val url: String? = null
)

@Serializable
data class ModrinthDonationUrl(
    val id: String,
    val platform: String,
    val url: String
)

@Serializable
data class ModrinthVersion(
    val id: String,
    val projectId: String,
    val authorId: String,
    val featured: Boolean,
    val name: String,
    val versionNumber: String,
    val changelog: String? = null,
    val datePublished: String,
    val downloads: Int,
    val versionType: String, // release, beta, alpha
    val files: List<ModrinthFile>,
    val dependencies: List<ModrinthDependency>,
    val gameVersions: List<String>,
    val loaders: List<String>
)

@Serializable
data class ModrinthFile(
    val hashes: ModrinthHashes,
    val url: String,
    val filename: String,
    val primary: Boolean,
    val size: Long,
    val fileType: String? = null
)

@Serializable
data class ModrinthHashes(
    val sha512: String,
    val sha1: String
)

@Serializable
data class ModrinthDependency(
    val versionId: String? = null,
    val projectId: String? = null,
    val fileName: String? = null,
    val dependencyType: String // required, optional, incompatible, embedded
)
