package com.verty.launcher.core.render

import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import org.lwjgl.glfw.GLFW

/**
 * Converts Android touch events to LWJGL mouse/keyboard input.
 * 
 * Mapping:
 * - Single touch = Mouse move + left click
 * - Long press = Right click
 * - Two fingers = Scroll
 * - Pinch = Zoom (F3 + scroll)
 * - Double tap = Sprint (double W)
 */
class TouchInputHandler(context: Context) {

    private var lastX = 0f
    private var lastY = 0f
    private var isDragging = false
    private var pointerCount = 0

    // Gesture detectors
    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onLongPress(e: MotionEvent) {
            // Long press = right click
            injectMouseButton(GLFW.GLFW_MOUSE_BUTTON_RIGHT, GLFW.GLFW_PRESS)
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            // Double tap = sprint (inject W key twice quickly)
            injectKey(GLFW.GLFW_KEY_W, GLFW.GLFW_PRESS)
            return true
        }
    })

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            // Pinch = zoom (F3 + scroll)
            val scale = detector.scaleFactor
            if (scale > 1.0f) {
                injectScroll(0.0, 1.0) // Zoom in
            } else {
                injectScroll(0.0, -1.0) // Zoom out
            }
            return true
        }
    })

    fun onTouchEvent(event: MotionEvent) {
        gestureDetector.onTouchEvent(event)
        scaleDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pointerCount = 1
                lastX = event.x
                lastY = event.y
                isDragging = false
                // Left mouse button press
                injectMouseButton(GLFW.GLFW_MOUSE_BUTTON_LEFT, GLFW.GLFW_PRESS)
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                pointerCount++
                if (pointerCount == 2) {
                    // Two fingers = cancel left click, prepare for scroll
                    injectMouseButton(GLFW.GLFW_MOUSE_BUTTON_LEFT, GLFW.GLFW_RELEASE)
                }
            }

            MotionEvent.ACTION_MOVE -> {
                if (pointerCount == 1) {
                    // Single finger = mouse move
                    val deltaX = event.x - lastX
                    val deltaY = event.y - lastY
                    lastX = event.x
                    lastY = event.y
                    isDragging = true
                    injectMouseMove(deltaX.toDouble(), deltaY.toDouble())
                } else if (pointerCount == 2) {
                    // Two fingers = scroll
                    val deltaY = event.y - lastY
                    injectScroll(0.0, deltaY.toDouble())
                    lastY = event.y
                }
            }

            MotionEvent.ACTION_UP -> {
                if (!isDragging) {
                    // Tap = left click release (already pressed on DOWN)
                    injectMouseButton(GLFW.GLFW_MOUSE_BUTTON_LEFT, GLFW.GLFW_RELEASE)
                }
                pointerCount = 0
                isDragging = false
            }

            MotionEvent.ACTION_POINTER_UP -> {
                pointerCount--
            }

            MotionEvent.ACTION_CANCEL -> {
                pointerCount = 0
                isDragging = false
            }
        }
    }

    private fun injectMouseMove(deltaX: Double, deltaY: Double) {
        // Call native method to inject into GLFW input queue
        NativeBridge.injectMouseMove(deltaX, deltaY)
    }

    private fun injectMouseButton(button: Int, action: Int) {
        NativeBridge.injectMouseButton(button, action)
    }

    private fun injectScroll(xOffset: Double, yOffset: Double) {
        NativeBridge.injectScroll(xOffset, yOffset)
    }

    private fun injectKey(key: Int, action: Int) {
        NativeBridge.injectKey(key, action)
    }
}
