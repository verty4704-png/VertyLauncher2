package com.verty.launcher.core.mods

import android.content.Context
import com.verty.launcher.core.download.DownloadTask
import com.verty.launcher.core.download.VertyDownloadManager
import com.verty.launcher.domain.model.ModLoader
import com.verty.launcher.util.ScopedStorageHelper
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.zip.ZipInputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ModLoaderInstaller @Inject constructor(
    @ApplicationContext private val context: Context,
    private val okHttpClient: OkHttpClient,
    private val downloadManager: VertyDownloadManager,
    private val json: Json
) {
    private val _installState = MutableStateFlow<InstallState>(InstallState.Idle)
    val installState: Flow<InstallState> = _installState.asStateFlow()

    sealed class InstallState {
        object Idle : InstallState()
        data class Downloading(val loader: String, val progress: Float) : InstallState()
        data class Installing(val loader: String) : InstallState()
        data class Completed(val loader: String, val version: String) : InstallState()
        data class Error(val loader: String, val message: String) : InstallState()
    }

    // ========== FABRIC ==========
    suspend fun installFabric(
        mcVersion: String,
        instanceDir: File,
        loaderVersion: String? = null
    ) = withContext(Dispatchers.IO) {
        _installState.value = InstallState.Downloading("Fabric", 0f)

        try {
            val version = loaderVersion ?: getLatestFabricLoaderVersion()
            val installerUrl = "https://maven.fabricmc.net/net/fabricmc/fabric-installer/$version/fabric-installer-$version.jar"
            val installerFile = File(context.cacheDir, "fabric-installer-$version.jar")

            // Download installer
            val task = DownloadTask(
                id = "fabric-installer-$version",
                url = installerUrl,
                destinationPath = installerFile.absolutePath,
                metadata = mapOf("type" to "fabric_installer")
            )
            downloadManager.enqueue(task)

            _installState.value = InstallState.Installing("Fabric")

            // Extract fabric loader libraries
            extractFabricLibraries(installerFile, instanceDir, mcVersion, version)

            // Create version JSON
            createFabricVersionJson(instanceDir, mcVersion, version)

            _installState.value = InstallState.Completed("Fabric", version)
        } catch (e: Exception) {
            _installState.value = InstallState.Error("Fabric", e.message ?: "Unknown error")
        }
    }

    private suspend fun getLatestFabricLoaderVersion(): String {
        val request = Request.Builder()
            .url("https://meta.fabricmc.net/v2/versions/loader")
            .build()

        val response = okHttpClient.newCall(request).execute()
        val versions = json.parseToJsonElement(response.body!!.string()).jsonArray
        return versions.first().jsonObject["version"]?.jsonPrimitive?.content ?: "0.15.0"
    }

    private fun extractFabricLibraries(installerFile: File, instanceDir: File, mcVersion: String, loaderVersion: String) {
        val librariesDir = File(instanceDir, "libraries").apply { mkdirs() }

        ZipInputStream(installerFile.inputStream()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (entry.name.startsWith("META-INF/jars/")) {
                    val destFile = File(librariesDir, entry.name.removePrefix("META-INF/jars/"))
                    destFile.parentFile?.mkdirs()
                    destFile.outputStream().use { zip.copyTo(it) }
                }
                entry = zip.nextEntry
            }
        }
    }

    private fun createFabricVersionJson(instanceDir: File, mcVersion: String, loaderVersion: String) {
        val versionJson = File(instanceDir, "versions/fabric-loader-$loaderVersion-$mcVersion.json")
        versionJson.parentFile?.mkdirs()

        val content = buildString {
            append("{\n")
            append("  \"id\": \"fabric-loader-$loaderVersion-$mcVersion\",\n")
            append("  \"inheritsFrom\": \"$mcVersion\",\n")
            append("  \"type\": \"release\",\n")
            append("  \"mainClass\": \"net.fabricmc.loader.impl.launch.knot.KnotClient\",\n")
            append("  \"libraries\": [\n")
            append("    { \"name\": \"net.fabricmc:fabric-loader:$loaderVersion\" },\n")
            append("    { \"name\": \"net.fabricmc:intermediary:$mcVersion\" }\n")
            append("  ]\n")
            append("}\n")
        }
        versionJson.writeText(content)
    }

    // ========== FORGE ==========
    suspend fun installForge(
        mcVersion: String,
        instanceDir: File,
        forgeVersion: String? = null
    ) = withContext(Dispatchers.IO) {
        _installState.value = InstallState.Downloading("Forge", 0f)

        try {
            val version = forgeVersion ?: getLatestForgeVersion(mcVersion)
            val installerUrl = "https://maven.minecraftforge.net/net/minecraftforge/forge/$mcVersion-$version/forge-$mcVersion-$version-installer.jar"
            val installerFile = File(context.cacheDir, "forge-installer-$mcVersion-$version.jar")

            val task = DownloadTask(
                id = "forge-installer-$mcVersion-$version",
                url = installerUrl,
                destinationPath = installerFile.absolutePath,
                metadata = mapOf("type" to "forge_installer")
            )
            downloadManager.enqueue(task)

            _installState.value = InstallState.Installing("Forge")
            extractForgeInstaller(installerFile, instanceDir, mcVersion, version)
            _installState.value = InstallState.Completed("Forge", version)
        } catch (e: Exception) {
            _installState.value = InstallState.Error("Forge", e.message ?: "Unknown error")
        }
    }

    private suspend fun getLatestForgeVersion(mcVersion: String): String {
        val request = Request.Builder()
            .url("https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json")
            .build()

        val response = okHttpClient.newCall(request).execute()
        val promotions = json.parseToJsonElement(response.body!!.string()).jsonObject
        val versionKey = promotions["promos"]?.jsonObject?.get("$mcVersion-recommended")?.jsonPrimitive?.content
            ?: promotions["promos"]?.jsonObject?.get("$mcVersion-latest")?.jsonPrimitive?.content
            ?: throw IllegalStateException("No Forge version found for $mcVersion")

        return versionKey
    }

    private fun extractForgeInstaller(installerFile: File, instanceDir: File, mcVersion: String, forgeVersion: String) {
        val librariesDir = File(instanceDir, "libraries").apply { mkdirs() }

        ZipInputStream(installerFile.inputStream()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (entry.name.startsWith("maven/")) {
                    val destFile = File(librariesDir, entry.name.removePrefix("maven/"))
                    destFile.parentFile?.mkdirs()
                    destFile.outputStream().use { zip.copyTo(it) }
                } else if (entry.name.endsWith("version.json")) {
                    val versionJson = File(instanceDir, "versions/$mcVersion-forge-$forgeVersion.json")
                    versionJson.parentFile?.mkdirs()
                    versionJson.outputStream().use { zip.copyTo(it) }
                }
                entry = zip.nextEntry
            }
        }
    }

    // ========== NEOFORGE ==========
    suspend fun installNeoForge(
        mcVersion: String,
        instanceDir: File,
        neoForgeVersion: String? = null
    ) = withContext(Dispatchers.IO) {
        _installState.value = InstallState.Downloading("NeoForge", 0f)

        try {
            val version = neoForgeVersion ?: getLatestNeoForgeVersion(mcVersion)
            val installerUrl = "https://maven.neoforged.net/releases/net/neoforged/neoforge/$version/neoforge-$version-installer.jar"
            val installerFile = File(context.cacheDir, "neoforge-installer-$version.jar")

            val task = DownloadTask(
                id = "neoforge-installer-$version",
                url = installerUrl,
                destinationPath = installerFile.absolutePath,
                metadata = mapOf("type" to "neoforge_installer")
            )
            downloadManager.enqueue(task)

            _installState.value = InstallState.Installing("NeoForge")
            extractNeoForgeInstaller(installerFile, instanceDir, version)
            _installState.value = InstallState.Completed("NeoForge", version)
        } catch (e: Exception) {
            _installState.value = InstallState.Error("NeoForge", e.message ?: "Unknown error")
        }
    }

    private suspend fun getLatestNeoForgeVersion(mcVersion: String): String {
        val request = Request.Builder()
            .url("https://maven.neoforged.net/api/maven/latest/version/releases/net/neoforged/neoforge")
            .build()

        val response = okHttpClient.newCall(request).execute()
        val result = json.parseToJsonElement(response.body!!.string()).jsonObject
        return result["version"]?.jsonPrimitive?.content ?: throw IllegalStateException("No NeoForge version found")
    }

    private fun extractNeoForgeInstaller(installerFile: File, instanceDir: File, version: String) {
        val librariesDir = File(instanceDir, "libraries").apply { mkdirs() }

        ZipInputStream(installerFile.inputStream()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (entry.name.startsWith("maven/")) {
                    val destFile = File(librariesDir, entry.name.removePrefix("maven/"))
                    destFile.parentFile?.mkdirs()
                    destFile.outputStream().use { zip.copyTo(it) }
                }
                entry = zip.nextEntry
            }
        }
    }

    // ========== QUILT ==========
    suspend fun installQuilt(
        mcVersion: String,
        instanceDir: File,
        quiltVersion: String? = null
    ) = withContext(Dispatchers.IO) {
        _installState.value = InstallState.Downloading("Quilt", 0f)

        try {
            val version = quiltVersion ?: getLatestQuiltVersion()
            val installerUrl = "https://maven.quiltmc.org/repository/release/org/quiltmc/quilt-installer/$version/quilt-installer-$version.jar"
            val installerFile = File(context.cacheDir, "quilt-installer-$version.jar")

            val task = DownloadTask(
                id = "quilt-installer-$version",
                url = installerUrl,
                destinationPath = installerFile.absolutePath,
                metadata = mapOf("type" to "quilt_installer")
            )
            downloadManager.enqueue(task)

            _installState.value = InstallState.Installing("Quilt")
            extractQuiltLibraries(installerFile, instanceDir, mcVersion, version)
            _installState.value = InstallState.Completed("Quilt", version)
        } catch (e: Exception) {
            _installState.value = InstallState.Error("Quilt", e.message ?: "Unknown error")
        }
    }

    private suspend fun getLatestQuiltVersion(): String {
        val request = Request.Builder()
            .url("https://meta.quiltmc.org/v3/versions/installer")
            .build()

        val response = okHttpClient.newCall(request).execute()
        val versions = json.parseToJsonElement(response.body!!.string()).jsonArray
        return versions.first().jsonObject["version"]?.jsonPrimitive?.content ?: "0.9.0"
    }

    private fun extractQuiltLibraries(installerFile: File, instanceDir: File, mcVersion: String, version: String) {
        val librariesDir = File(instanceDir, "libraries").apply { mkdirs() }

        ZipInputStream(installerFile.inputStream()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (entry.name.startsWith("META-INF/jars/")) {
                    val destFile = File(librariesDir, entry.name.removePrefix("META-INF/jars/"))
                    destFile.parentFile?.mkdirs()
                    destFile.outputStream().use { zip.copyTo(it) }
                }
                entry = zip.nextEntry
            }
        }
    }

    suspend fun installLoader(
        loader: ModLoader,
        mcVersion: String,
        instanceDir: File,
        version: String? = null
    ) {
        when (loader) {
            ModLoader.FABRIC -> installFabric(mcVersion, instanceDir, version)
            ModLoader.FORGE -> installForge(mcVersion, instanceDir, version)
            ModLoader.NEOFORGE -> installNeoForge(mcVersion, instanceDir, version)
            ModLoader.QUILT -> installQuilt(mcVersion, instanceDir, version)
            ModLoader.VANILLA -> {} // Nothing to install
        }
    }
}
