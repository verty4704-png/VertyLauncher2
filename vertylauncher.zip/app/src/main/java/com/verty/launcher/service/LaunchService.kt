package com.verty.launcher.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.verty.launcher.MainActivity
import com.verty.launcher.R
import com.verty.launcher.core.native.NativeBridge
import com.verty.launcher.data.repository.InstanceRepository
import com.verty.launcher.domain.model.MinecraftInstance
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class LaunchService : Service() {

    @Inject
    lateinit var instanceRepository: InstanceRepository

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val notificationManager by lazy {
        getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    companion object {
        const val CHANNEL_ID = "verty_launch"
        const val NOTIFICATION_ID = 1001
        const val ACTION_LAUNCH = "com.verty.launcher.ACTION_LAUNCH"
        const val EXTRA_INSTANCE_ID = "instance_id"

        private val _launchState = MutableStateFlow<LaunchState>(LaunchState.Idle)
        val launchState = _launchState.asStateFlow()
    }

    sealed class LaunchState {
        object Idle : LaunchState()
        data class Preparing(val instanceId: String) : LaunchState()
        data class DownloadingAssets(val progress: Float) : LaunchState()
        data class Loading(val message: String) : LaunchState()
        data class Running(val pid: Int) : LaunchState()
        data class Error(val message: String) : LaunchState()
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        NativeBridge.installCrashHandler()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val instanceId = intent?.getStringExtra(EXTRA_INSTANCE_ID) ?: return START_NOT_STICKY

        startForeground(NOTIFICATION_ID, buildNotification("Preparing launch..."))

        serviceScope.launch {
            launchMinecraft(instanceId)
        }

        return START_NOT_STICKY
    }

    private suspend fun launchMinecraft(instanceId: String) {
        _launchState.value = LaunchState.Preparing(instanceId)

        val instance = instanceRepository.getInstance(instanceId)
            ?: run {
                _launchState.value = LaunchState.Error("Instance not found")
                stopSelf()
                return
            }

        try {
            // Phase 1: Validate files
            _launchState.value = LaunchState.Loading("Validating game files...")
            validateGameFiles(instance)

            // Phase 2: Download missing assets
            _launchState.value = LaunchState.DownloadingAssets(0f)
            downloadMissingAssets(instance)

            // Phase 3: Build JVM arguments
            _launchState.value = LaunchState.Loading("Building JVM configuration...")
            val jvmArgs = buildJvmArgs(instance)

            // Phase 4: Launch process
            _launchState.value = LaunchState.Loading("Starting Minecraft...")
            val process = startMinecraftProcess(instance, jvmArgs)

            _launchState.value = LaunchState.Running(process.pid())
            updateNotification("Minecraft is running", false)

            // Monitor process
            process.waitFor()
            _launchState.value = LaunchState.Idle

        } catch (e: Exception) {
            _launchState.value = LaunchState.Error(e.message ?: "Unknown launch error")
            updateNotification("Launch failed: ${e.message}", true)
        } finally {
            stopSelf()
        }
    }

    private fun validateGameFiles(instance: MinecraftInstance) {
        val instanceDir = instanceRepository.getInstanceDir(instance.id)
        // Validate essential files exist
        val essentialFiles = listOf(
            "versions/${instance.version}/${instance.version}.jar",
            "libraries"
        )
        // Implementation would check each file
    }

    private suspend fun downloadMissingAssets(instance: MinecraftInstance) {
        // Asset download logic
        _launchState.value = LaunchState.DownloadingAssets(1f)
    }

    private fun buildJvmArgs(instance: MinecraftInstance): List<String> {
        val nativeArgs = NativeBridge.buildOptimizedJvmArgs(
            maxMemoryMb = instance.maxMemoryMb,
            useG1GC = true,
            useStringDeduplication = true,
            aggressiveOpts = true
        )
        return nativeArgs.toList() + instance.jvmArgs
    }

    private fun startMinecraftProcess(instance: MinecraftInstance, jvmArgs: List<String>): Process {
        val instanceDir = instanceRepository.getInstanceDir(instance.id)
        val javaExe = File(instanceDir, "java/bin/java").absolutePath

        val command = mutableListOf(javaExe)
        command.addAll(jvmArgs)
        command.add("-cp", buildClasspath(instance))
        command.add("net.minecraft.client.main.Main")
        command.addAll(instance.gameArgs)

        return ProcessBuilder(command)
            .directory(instanceDir)
            .redirectErrorStream(true)
            .start()
    }

    private fun buildClasspath(instance: MinecraftInstance): String {
        // Build classpath from libraries and version jar
        return ""
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Minecraft Launch",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows Minecraft launch progress"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): android.app.Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VertyLauncher")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun updateNotification(text: String, error: Boolean) {
        val notification = buildNotification(text).apply {
            // Update with error styling if needed
        }
        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }
}
