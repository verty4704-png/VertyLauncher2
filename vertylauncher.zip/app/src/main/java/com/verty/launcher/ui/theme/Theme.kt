package com.verty.launcher.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.google.accompanist.systemuicontroller.rememberSystemUiController

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF8B9DFF),
    onPrimary = Color(0xFF000000),
    primaryContainer = Color(0xFF1A1F3D),
    onPrimaryContainer = Color(0xFFD0D8FF),
    secondary = Color(0xFF7DD3FC),
    onSecondary = Color(0xFF000000),
    secondaryContainer = Color(0xFF152238),
    onSecondaryContainer = Color(0xFFB8E0FF),
    tertiary = Color(0xFFA78BFA),
    onTertiary = Color(0xFF000000),
    tertiaryContainer = Color(0xFF1E1B4B),
    onTertiaryContainer = Color(0xFFD8C4FF),
    error = Color(0xFFFF6B6B),
    errorContainer = Color(0xFF3D1515),
    onError = Color(0xFF000000),
    onErrorContainer = Color(0xFFFFB4B4),
    background = Color(0xFF0A0A0F),
    onBackground = Color(0xFFE2E2E8),
    surface = Color(0xFF12121A),
    onSurface = Color(0xFFE2E2E8),
    surfaceVariant = Color(0xFF1A1A24),
    onSurfaceVariant = Color(0xFFB0B0C0),
    outline = Color(0xFF404050),
    inverseOnSurface = Color(0xFF0A0A0F),
    inverseSurface = Color(0xFFE2E2E8),
    inversePrimary = Color(0xFF5C7CFF),
    surfaceTint = Color(0xFF8B9DFF),
    outlineVariant = Color(0xFF2A2A3A),
    scrim = Color(0xFF000000),
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF4F5DFF),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE0E4FF),
    onPrimaryContainer = Color(0xFF000A5C),
    secondary = Color(0xFF0284C7),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFD0E8FF),
    onSecondaryContainer = Color(0xFF001D35),
    tertiary = Color(0xFF7C3AED),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFE9D5FF),
    onTertiaryContainer = Color(0xFF280055),
    error = Color(0xFFDC2626),
    errorContainer = Color(0xFFFFDAD6),
    onError = Color(0xFFFFFFFF),
    onErrorContainer = Color(0xFF410002),
    background = Color(0xFFF8F9FE),
    onBackground = Color(0xFF1A1B21),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1A1B21),
    surfaceVariant = Color(0xFFE2E2EC),
    onSurfaceVariant = Color(0xFF45464F),
    outline = Color(0xFF767680),
    inverseOnSurface = Color(0xFFF2F0F4),
    inverseSurface = Color(0xFF303034),
    inversePrimary = Color(0xFFBDC2FF),
    surfaceTint = Color(0xFF4F5DFF),
    outlineVariant = Color(0xFFC6C6D0),
    scrim = Color(0xFF000000),
)

@Composable
fun VertyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val view = LocalView.current
    val systemUiController = rememberSystemUiController()

    SideEffect {
        val window = (view.context as Activity).window
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme

        systemUiController.setSystemBarsColor(
            color = Color.Transparent,
            darkIcons = !darkTheme
        )
        systemUiController.setNavigationBarColor(
            color = Color.Transparent,
            darkIcons = !darkTheme
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = VertyTypography,
        content = content
    )
}
