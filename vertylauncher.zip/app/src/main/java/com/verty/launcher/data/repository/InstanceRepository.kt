package com.verty.launcher.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.verty.launcher.domain.model.MinecraftInstance
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class InstanceRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val dataStore: DataStore<Preferences>,
    private val json: Json
) {
    companion object {
        private val INSTANCES_KEY = stringPreferencesKey("instances")
    }

    private val _instances = MutableStateFlow<List<MinecraftInstance>>(emptyList())
    val instances: Flow<List<MinecraftInstance>> = _instances.asStateFlow()

    val favoriteInstances: Flow<List<MinecraftInstance>> = _instances.map { list ->
        list.filter { it.isFavorite }.sortedByDescending { it.lastPlayed }
    }

    val recentInstances: Flow<List<MinecraftInstance>> = _instances.map { list ->
        list.filter { it.lastPlayed != null }
            .sortedByDescending { it.lastPlayed }
            .take(5)
    }

    suspend fun loadInstances() {
        val prefs = dataStore.data.first()
        val data = prefs[INSTANCES_KEY] ?: "[]"
        _instances.value = json.decodeFromString(data)
    }

    suspend fun createInstance(instance: MinecraftInstance) {
        val instancesDir = File(context.filesDir, "instances/${instance.id}")
        instancesDir.mkdirs()

        val current = _instances.value.toMutableList()
        current.add(instance)
        _instances.value = current
        saveInstances()
    }

    suspend fun updateInstance(instance: MinecraftInstance) {
        val current = _instances.value.toMutableList()
        val index = current.indexOfFirst { it.id == instance.id }
        if (index != -1) {
            current[index] = instance
            _instances.value = current
            saveInstances()
        }
    }

    suspend fun deleteInstance(instanceId: String) {
        val instancesDir = File(context.filesDir, "instances/$instanceId")
        instancesDir.deleteRecursively()

        _instances.value = _instances.value.filter { it.id != instanceId }
        saveInstances()
    }

    suspend fun getInstance(instanceId: String): MinecraftInstance? {
        return _instances.value.find { it.id == instanceId }
    }

    fun getInstanceDir(instanceId: String): File {
        return File(context.filesDir, "instances/$instanceId")
    }

    private suspend fun saveInstances() {
        dataStore.edit { prefs ->
            prefs[INSTANCES_KEY] = json.encodeToString(_instances.value)
        }
    }
}
