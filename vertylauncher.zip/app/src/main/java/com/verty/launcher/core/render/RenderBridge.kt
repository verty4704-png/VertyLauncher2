package com.verty.launcher.core.render

import android.opengl.GLES30
import com.verty.launcher.core.native.NativeBridge
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RenderBridge @Inject constructor() {

    enum class Backend { OPENGL_ES, VULKAN, SOFTWARE }

    val availableBackends: List<Backend>
        get() = buildList {
            add(Backend.OPENGL_ES)
            if (NativeBridge.isVulkanSupported()) add(Backend.VULKAN)
        }

    val recommendedBackend: Backend
        get() = when {
            NativeBridge.isVulkanSupported() && getGLESVersion() >= 32 -> Backend.VULKAN
            getGLESVersion() >= 30 -> Backend.OPENGL_ES
            else -> Backend.SOFTWARE
        }

    val gpuInfo: String
        get() = NativeBridge.getGpuInfo()

    val glesVersion: Int
        get() = NativeBridge.getGLESVersion()

    fun hasExtension(extension: String): Boolean =
        NativeBridge.hasExtension(extension)

    fun setVSync(enabled: Boolean) {
        NativeBridge.setSwapInterval(if (enabled) 1 else 0)
    }

    fun getRecommendedSettings(): RenderSettings {
        val version = getGLESVersion()
        val totalRam = NativeBridge.getAvailableMemory() / (1024 * 1024)

        return when {
            version >= 32 && totalRam >= 4096 -> RenderSettings.HIGH
            version >= 30 && totalRam >= 2048 -> RenderSettings.MEDIUM
            else -> RenderSettings.LOW
        }
    }

    data class RenderSettings(
        val renderDistance: Int,
        val maxFps: Int,
        val graphicsQuality: String,
        val enableVBO: Boolean,
        val useVAO: Boolean,
        val anisotropicFiltering: Int
    ) {
        companion object {
            val HIGH = RenderSettings(
                renderDistance = 12,
                maxFps = 120,
                graphicsQuality = "fancy",
                enableVBO = true,
                useVAO = true,
                anisotropicFiltering = 4
            )
            val MEDIUM = RenderSettings(
                renderDistance = 8,
                maxFps = 60,
                graphicsQuality = "fast",
                enableVBO = true,
                useVAO = false,
                anisotropicFiltering = 2
            )
            val LOW = RenderSettings(
                renderDistance = 4,
                maxFps = 30,
                graphicsQuality = "fast",
                enableVBO = true,
                useVAO = false,
                anisotropicFiltering = 0
            )
        }
    }
}
