package com.verty.launcher.core.account

import com.verty.launcher.domain.model.Account
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OfflineAuth @Inject constructor() {

    fun createAccount(username: String): Account.OfflineAccount {
        val uuid = UUID.nameUUIDFromBytes("OfflinePlayer:$username".toByteArray())
        return Account.OfflineAccount(
            id = uuid.toString().replace("-", ""),
            username = username,
            uuid = uuid.toString()
        )
    }
}
