package com.verty.launcher.core.runtime

import android.content.Context
import com.verty.launcher.core.download.DownloadTask
import com.verty.launcher.core.download.VertyDownloadManager
import com.verty.launcher.domain.model.JavaRuntime
import com.verty.launcher.util.ScopedStorageHelper
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipInputStream
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class JavaRuntimeDownloader @Inject constructor(
    @ApplicationContext private val context: Context,
    private val downloadManager: VertyDownloadManager
) {
    private val _downloadState = MutableStateFlow<DownloadState>(DownloadState.Idle)
    val downloadState: Flow<DownloadState> = _downloadState.asStateFlow()

    sealed class DownloadState {
        object Idle : DownloadState()
        data class Downloading(val runtime: String, val progress: Float) : DownloadState()
        data class Extracting(val runtime: String) : DownloadState()
        data class Completed(val runtime: JavaRuntime) : DownloadState()
        data class Error(val runtime: String, val message: String) : DownloadState()
    }

    companion object {
        // Azul Zulu JRE builds for Android (ARM64)
        private const val ZULU_BASE_URL = "https://cdn.azul.com/zulu/bin"

        // Adoptium (Eclipse Temurin) builds
        private const val ADOPTIUM_API = "https://api.adoptium.net/v3/binary/latest"

        // PojavLauncher JRE17 fork (optimized for Android)
        private const val POJAV_JRE17_URL = "https://github.com/PojavLauncherTeam/android-openjdk-build-multiarch/releases/download/jre17-arm64-20240101/jre17-arm64-20240101.tar.xz"
        private const val POJAV_JRE8_URL = "https://github.com/PojavLauncherTeam/android-openjdk-build-multiarch/releases/download/jre8-arm64-20240101/jre8-arm64-20240101.tar.xz"
        private const val POJAV_JRE21_URL = "https://github.com/PojavLauncherTeam/android-openjdk-build-multiarch/releases/download/jre21-arm64-20240101/jre21-arm64-20240101.tar.xz"
    }

    val availableRuntimes: List<JavaRuntime>
        get() = listOf(
            JavaRuntime(
                id = "zulu-17",
                version = 17,
                vendor = "Azul Zulu",
                path = "",
                isInstalled = false,
                downloadUrl = "$ZULU_BASE_URL/zulu17.46.19-ca-jre17.0.9-linux_aarch64.tar.gz",
                size = 42_000_000L
            ),
            JavaRuntime(
                id = "zulu-21",
                version = 21,
                vendor = "Azul Zulu",
                path = "",
                isInstalled = false,
                downloadUrl = "$ZULU_BASE_URL/zulu21.30.15-ca-jre21.0.1-linux_aarch64.tar.gz",
                size = 48_000_000L
            ),
            JavaRuntime(
                id = "pojav-17",
                version = 17,
                vendor = "PojavLauncher (Android Optimized)",
                path = "",
                isInstalled = false,
                downloadUrl = POJAV_JRE17_URL,
                size = 55_000_000L
            ),
            JavaRuntime(
                id = "pojav-8",
                version = 8,
                vendor = "PojavLauncher (Android Optimized)",
                path = "",
                isInstalled = false,
                downloadUrl = POJAV_JRE8_URL,
                size = 35_000_000L
            ),
            JavaRuntime(
                id = "pojav-21",
                version = 21,
                vendor = "PojavLauncher (Android Optimized)",
                path = "",
                isInstalled = false,
                downloadUrl = POJAV_JRE21_URL,
                size = 60_000_000L
            )
        )

    suspend fun downloadAndInstall(runtime: JavaRuntime) = withContext(Dispatchers.IO) {
        _downloadState.value = DownloadState.Downloading(runtime.id, 0f)

        val javaDir = ScopedStorageHelper.getJavaDir(context)
        val targetDir = File(javaDir, runtime.id)
        val downloadFile = File(context.cacheDir, "${runtime.id}.download")

        try {
            val downloadUrl = runtime.downloadUrl
                ?: throw IllegalStateException("No download URL for ${runtime.id}")

            val task = DownloadTask(
                id = "java-${runtime.id}",
                url = downloadUrl,
                destinationPath = downloadFile.absolutePath,
                expectedSize = runtime.size,
                metadata = mapOf("type" to "java_runtime", "version" to runtime.version.toString())
            )
            downloadManager.enqueue(task)

            // Wait for download (in production, observe download events)
            _downloadState.value = DownloadState.Extracting(runtime.id)

            targetDir.mkdirs()
            extractJavaRuntime(downloadFile, targetDir)

            val installed = runtime.copy(
                path = targetDir.absolutePath,
                isInstalled = true
            )

            _downloadState.value = DownloadState.Completed(installed)
        } catch (e: Exception) {
            _downloadState.value = DownloadState.Error(runtime.id, e.message ?: "Unknown error")
            targetDir.deleteRecursively()
        } finally {
            downloadFile.delete()
        }
    }

    private fun extractJavaRuntime(archiveFile: File, targetDir: File) {
        when {
            archiveFile.name.endsWith(".tar.gz") || archiveFile.name.endsWith(".tgz") -> {
                extractTarGz(archiveFile, targetDir)
            }
            archiveFile.name.endsWith(".tar.xz") -> {
                extractTarXz(archiveFile, targetDir)
            }
            archiveFile.name.endsWith(".zip") -> {
                extractZip(archiveFile, targetDir)
            }
            else -> throw IllegalArgumentException("Unsupported archive format: ${archiveFile.name}")
        }

        // Find the actual JRE directory (usually nested one level deep)
        val jreRoot = targetDir.listFiles()?.firstOrNull { it.isDirectory }
        if (jreRoot != null && jreRoot != targetDir) {
            // Move contents up one level
            jreRoot.listFiles()?.forEach { file ->
                file.renameTo(File(targetDir, file.name))
            }
            jreRoot.delete()
        }

        // Verify installation
        val javaBin = File(targetDir, "bin/java")
        if (!javaBin.exists()) {
            throw IllegalStateException("Java binary not found after extraction")
        }

        // Make binary executable
        javaBin.setExecutable(true)
    }

    private fun extractZip(archiveFile: File, targetDir: File) {
        ZipInputStream(archiveFile.inputStream()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val destFile = File(targetDir, entry.name)
                if (entry.isDirectory) {
                    destFile.mkdirs()
                } else {
                    destFile.parentFile?.mkdirs()
                    destFile.outputStream().use { zip.copyTo(it) }
                }
                entry = zip.nextEntry
            }
        }
    }

    private fun extractTarGz(archiveFile: File, targetDir: File) {
        // Use Runtime.exec for tar extraction (more reliable on Android)
        val process = Runtime.getRuntime().exec(
            arrayOf("tar", "-xzf", archiveFile.absolutePath, "-C", targetDir.absolutePath)
        )
        process.waitFor()
        if (process.exitValue() != 0) {
            throw IllegalStateException("tar extraction failed: ${process.errorStream.reader().readText()}")
        }
    }

    private fun extractTarXz(archiveFile: File, targetDir: File) {
        val process = Runtime.getRuntime().exec(
            arrayOf("tar", "-xJf", archiveFile.absolutePath, "-C", targetDir.absolutePath)
        )
        process.waitFor()
        if (process.exitValue() != 0) {
            throw IllegalStateException("tar extraction failed: ${process.errorStream.reader().readText()}")
        }
    }

    fun getJavaExecutable(runtimeId: String): File? {
        val javaDir = ScopedStorageHelper.getJavaDir(context)
        val runtimeDir = File(javaDir, runtimeId)
        val javaBin = File(runtimeDir, "bin/java")
        return if (javaBin.exists()) javaBin else null
    }

    fun isRuntimeInstalled(runtimeId: String): Boolean {
        return getJavaExecutable(runtimeId) != null
    }

    fun getRecommendedRuntime(mcVersion: String): String {
        return when {
            mcVersion.startsWith("1.20.5") || mcVersion >= "1.21" -> "pojav-21"
            mcVersion >= "1.18" -> "pojav-17"
            else -> "pojav-8"
        }
    }
}
