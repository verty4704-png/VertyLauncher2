package com.verty.launcher.data.repository

import com.verty.launcher.core.security.SecureStorage
import com.verty.launcher.domain.model.Account
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AccountRepository @Inject constructor(
    private val secureStorage: SecureStorage,
    private val json: Json
) {
    companion object {
        private const val KEY_ACCOUNTS = "accounts"
        private const val KEY_ACTIVE_ACCOUNT = "active_account"
    }

    private val _accounts = MutableStateFlow<List<Account>>(emptyList())
    val accounts: Flow<List<Account>> = _accounts.asStateFlow()

    private val _activeAccount = MutableStateFlow<Account?>(null)
    val activeAccount: Flow<Account?> = _activeAccount.asStateFlow()

    suspend fun loadAccounts() {
        val data = secureStorage.retrieve(KEY_ACCOUNTS) ?: "[]"
        _accounts.value = json.decodeFromString(data)

        val activeId = secureStorage.retrieve(KEY_ACTIVE_ACCOUNT)
        _activeAccount.value = _accounts.value.find { it.id == activeId }
    }

    suspend fun addAccount(account: Account) {
        val current = _accounts.value.toMutableList()
        current.removeAll { it.id == account.id }
        current.add(account)
        _accounts.value = current
        saveAccounts()

        if (_activeAccount.value == null) {
            setActiveAccount(account.id)
        }
    }

    suspend fun removeAccount(accountId: String) {
        _accounts.value = _accounts.value.filter { it.id != accountId }
        saveAccounts()

        if (_activeAccount.value?.id == accountId) {
            _activeAccount.value = _accounts.value.firstOrNull()
            _activeAccount.value?.let { secureStorage.store(KEY_ACTIVE_ACCOUNT, it.id) }
                ?: secureStorage.remove(KEY_ACTIVE_ACCOUNT)
        }
    }

    suspend fun setActiveAccount(accountId: String) {
        val account = _accounts.value.find { it.id == accountId }
        _activeAccount.value = account
        account?.let { secureStorage.store(KEY_ACTIVE_ACCOUNT, it.id) }
    }

    private suspend fun saveAccounts() {
        secureStorage.store(KEY_ACCOUNTS, json.encodeToString(_accounts.value))
    }
}
