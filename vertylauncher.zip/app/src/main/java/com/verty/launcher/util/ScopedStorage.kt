package com.verty.launcher.util

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import androidx.core.content.FileProvider
import java.io.File

object ScopedStorageHelper {

    fun getAppDataDir(context: Context): File {
        return context.filesDir
    }

    fun getCacheDir(context: Context): File {
        return context.cacheDir
    }

    fun getInstancesDir(context: Context): File {
        return File(context.filesDir, "instances").apply { mkdirs() }
    }

    fun getJavaDir(context: Context): File {
        return File(context.filesDir, "java").apply { mkdirs() }
    }

    fun getAssetsDir(context: Context): File {
        return File(context.filesDir, "assets").apply { mkdirs() }
    }

    fun getLibrariesDir(context: Context): File {
        return File(context.filesDir, "libraries").apply { mkdirs() }
    }

    fun getVersionsDir(context: Context): File {
        return File(context.filesDir, "versions").apply { mkdirs() }
    }

    fun getModsDir(context: Context, instanceId: String): File {
        return File(getInstancesDir(context), "$instanceId/mods").apply { mkdirs() }
    }

    fun getShaderPacksDir(context: Context, instanceId: String): File {
        return File(getInstancesDir(context), "$instanceId/shaderpacks").apply { mkdirs() }
    }

    fun getScreenshotsDir(context: Context, instanceId: String): File {
        return File(getInstancesDir(context), "$instanceId/screenshots").apply { mkdirs() }
    }

    fun getUriForFile(context: Context, file: File): Uri {
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }

    fun isExternalStorageAvailable(): Boolean {
        return Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED
    }
}
