package com.verty.launcher.core

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Process
import com.verty.launcher.core.native.NativeBridge
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PerformanceMonitor @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val _metrics = MutableStateFlow(SystemMetrics())
    val metrics: Flow<SystemMetrics> = _metrics.asStateFlow()

    private val _fps = MutableStateFlow(0)
    val fps: Flow<Int> = _fps.asStateFlow()

    fun startMonitoring(scope: CoroutineScope) {
        scope.launch(Dispatchers.Default) {
            while (isActive) {
                val memInfo = ActivityManager.MemoryInfo()
                activityManager.getMemoryInfo(memInfo)

                val runtime = Runtime.getRuntime()
                val usedMem = (runtime.totalMemory() - runtime.freeMemory()) / 1024 / 1024
                val totalMem = runtime.maxMemory() / 1024 / 1024

                _metrics.value = SystemMetrics(
                    availableRamMb = memInfo.availMem / 1024 / 1024,
                    totalRamMb = memInfo.totalMem / 1024 / 1024,
                    launcherUsedRamMb = usedMem.toInt(),
                    nativeHeapMb = (NativeBridge.getNativeHeapSize() / 1024 / 1024).toInt(),
                    cpuUsage = getCpuUsage(),
                    batteryTemp = getBatteryTemp(),
                    isLowMemory = memInfo.lowMemory
                )

                delay(1000)
            }
        }
    }

    private fun getCpuUsage(): Float {
        return try {
            val pid = Process.myPid()
            val statFile = "/proc/$pid/stat"
            // Parse CPU usage from procfs
            0f // Simplified - real implementation would parse /proc/stat
        } catch (_: Exception) {
            0f
        }
    }

    private fun getBatteryTemp(): Float {
        // Would read from BatteryManager in real implementation
        return 0f
    }

    fun getRecommendedMemory(): Int {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        val totalMb = memInfo.totalMem / 1024 / 1024

        return when {
            totalMb < 2048 -> 512      // Very low-end (Redmi 8 class)
            totalMb < 4096 -> 1024     // Low-end
            totalMb < 6144 -> 2048     // Mid-range
            totalMb < 8192 -> 3072     // Upper mid
            else -> 4096               // High-end
        }
    }

    fun getGraphicsPreset(): GraphicsPreset {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        val totalMb = memInfo.totalMem / 1024 / 1024

        return when {
            totalMb < 3072 -> GraphicsPreset.LOW
            totalMb < 6144 -> GraphicsPreset.MEDIUM
            else -> GraphicsPreset.HIGH
        }
    }
}

data class SystemMetrics(
    val availableRamMb: Long = 0,
    val totalRamMb: Long = 0,
    val launcherUsedRamMb: Int = 0,
    val nativeHeapMb: Int = 0,
    val cpuUsage: Float = 0f,
    val batteryTemp: Float = 0f,
    val isLowMemory: Boolean = false
)

enum class GraphicsPreset {
    LOW, MEDIUM, HIGH, ULTRA
}
