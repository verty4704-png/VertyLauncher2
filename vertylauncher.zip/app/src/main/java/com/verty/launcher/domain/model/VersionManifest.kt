package com.verty.launcher.domain.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class VersionManifest(
    val latest: LatestVersions,
    val versions: List<VersionInfo>
)

@Serializable
data class LatestVersions(
    val release: String,
    val snapshot: String
)

@Serializable
data class VersionInfo(
    val id: String,
    val type: String,
    val url: String,
    val time: String,
    @SerialName("releaseTime") val releaseTime: String
)
