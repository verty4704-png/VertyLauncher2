package com.verty.launcher.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.verty.launcher.ui.screens.DashboardScreen
import com.verty.launcher.ui.screens.DownloadsScreen
import com.verty.launcher.ui.screens.InstanceManagerScreen
import com.verty.launcher.ui.screens.ModManagerScreen
import com.verty.launcher.ui.screens.SettingsScreen
import com.verty.launcher.ui.screens.AccountScreen
import com.verty.launcher.ui.screens.JavaManagerScreen
import com.verty.launcher.ui.screens.LaunchScreen
import com.verty.launcher.ui.screens.DiagnosticScreen

sealed class Screen(val route: String) {
    object Dashboard : Screen("dashboard")
    object Launch : Screen("launch/{instanceId}")
    object Instances : Screen("instances")
    object Mods : Screen("mods")
    object Downloads : Screen("downloads")
    object Settings : Screen("settings")
    object Account : Screen("account")
    object Java : Screen("java")
    object Diagnostics : Screen("diagnostics")
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun VertyNavHost(
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController(),
    startDestination: String = Screen.Dashboard.route
) {
    val transitionSpec = tween<Float>(durationMillis = 300)

    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = modifier,
        enterTransition = {
            fadeIn(transitionSpec) + scaleIn(
                initialScale = 0.95f,
                animationSpec = transitionSpec
            )
        },
        exitTransition = {
            fadeOut(transitionSpec) + scaleOut(
                targetScale = 1.05f,
                animationSpec = transitionSpec
            )
        },
        popEnterTransition = {
            fadeIn(transitionSpec) + scaleIn(
                initialScale = 1.05f,
                animationSpec = transitionSpec
            )
        },
        popExitTransition = {
            fadeOut(transitionSpec) + scaleOut(
                targetScale = 0.95f,
                animationSpec = transitionSpec
            )
        }
    ) {
        composable(Screen.Dashboard.route) {
            DashboardScreen(
                onNavigate = { route -> navController.navigate(route) },
                onLaunch = { instanceId -> navController.navigate("launch/$instanceId") }
            )
        }
        composable(Screen.Instances.route) {
            InstanceManagerScreen(onBack = { navController.popBackStack() })
        }
        composable(Screen.Mods.route) {
            ModManagerScreen(onBack = { navController.popBackStack() })
        }
        composable(Screen.Downloads.route) {
            DownloadsScreen(onBack = { navController.popBackStack() })
        }
        composable(Screen.Settings.route) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
        composable(Screen.Account.route) {
            AccountScreen(onBack = { navController.popBackStack() })
        }
        composable(Screen.Java.route) {
            JavaManagerScreen(onBack = { navController.popBackStack() })
        }
        composable(Screen.Diagnostics.route) {
            DiagnosticScreen(onBack = { navController.popBackStack() })
        }
        composable("launch/{instanceId}") { backStackEntry ->
            val instanceId = backStackEntry.arguments?.getString("instanceId") ?: ""
            LaunchScreen(
                instanceId = instanceId,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
