package com.verty.launcher.data.repository

import android.content.Context
import com.verty.launcher.domain.model.JavaRuntime
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class JavaRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val _runtimes = MutableStateFlow<List<JavaRuntime>>(emptyList())
    val runtimes: Flow<List<JavaRuntime>> = _runtimes.asStateFlow()

    private val javaDir: File
        get() = File(context.filesDir, "java")

    suspend fun scanRuntimes() {
        val found = mutableListOf<JavaRuntime>()

        if (!javaDir.exists()) {
            javaDir.mkdirs()
            _runtimes.value = emptyList()
            return
        }

        javaDir.listFiles()?.forEach { dir ->
            if (dir.isDirectory) {
                val javaBin = File(dir, "bin/java")
                if (javaBin.exists()) {
                    val version = detectJavaVersion(dir)
                    found.add(
                        JavaRuntime(
                            id = dir.name,
                            version = version,
                            vendor = "Auto-detected",
                            path = dir.absolutePath,
                            isInstalled = true
                        )
                    )
                }
            }
        }

        _runtimes.value = found
    }

    suspend fun installRuntime(runtime: JavaRuntime): Boolean {
        val targetDir = File(javaDir, runtime.id)
        targetDir.mkdirs()
        // Download and extract logic would go here
        return true
    }

    suspend fun setDefault(runtimeId: String) {
        _runtimes.value = _runtimes.value.map {
            it.copy(isDefault = it.id == runtimeId)
        }
    }

    fun getJavaExecutable(runtimeId: String): File? {
        val runtime = _runtimes.value.find { it.id == runtimeId } ?: return null
        return File(runtime.path, "bin/java")
    }

    private fun detectJavaVersion(dir: File): Int {
        // Simple version detection from directory name or release file
        val releaseFile = File(dir, "release")
        if (releaseFile.exists()) {
            val content = releaseFile.readText()
            val match = Regex("JAVA_VERSION=\"(\d+)").find(content)
            match?.groupValues?.get(1)?.toIntOrNull()?.let { return it }
        }
        return 17 // Default
    }
}
