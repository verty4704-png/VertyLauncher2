package com.verty.launcher.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.verty.launcher.core.PerformanceMonitor
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val performanceMonitor: PerformanceMonitor
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    val systemMetrics = performanceMonitor.metrics

    fun toggleSetting(key: String, value: Boolean) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                settings = _uiState.value.settings.toMutableMap().apply {
                    put(key, value)
                }
            )
        }
    }

    fun getRecommendedMemory(): Int = performanceMonitor.getRecommendedMemory()
    fun getGraphicsPreset() = performanceMonitor.getGraphicsPreset()
}

data class SettingsUiState(
    val settings: Map<String, Boolean> = emptyMap(),
    val isLoading: Boolean = false
)
