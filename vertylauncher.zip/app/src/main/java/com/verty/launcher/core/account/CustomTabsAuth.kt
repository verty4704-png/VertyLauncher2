package com.verty.launcher.core.account

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import com.verty.launcher.R
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Custom Tabs OAuth helper.
 * 
 * HOW IT WORKS:
 * 1. User clicks "Login with Microsoft" in app
 * 2. We build OAuth URL with PKCE params
 * 3. Open Chrome Custom Tab with this URL
 * 4. User logs in on Microsoft website
 * 5. Microsoft redirects to: ms-xal-00000000402b5324://auth?code=XXX
 * 6. Android catches this deep link in MainActivity
 * 7. MainActivity extracts auth code and passes it back
 * 8. We exchange code for tokens
 */
object CustomTabsAuth {

    fun openAuthPage(activity: Activity, authUrl: String) {
        val customTabsIntent = CustomTabsIntent.Builder()
            .setShowTitle(true)
            .setUrlBarHidingEnabled(true)
            .setColorScheme(CustomTabsIntent.COLOR_SCHEME_DARK)
            .setDefaultColorSchemeParams(
                CustomTabColorSchemeParams.Builder()
                    .setToolbarColor(ContextCompat.getColor(activity, R.color.ic_launcher_background))
                    .setNavigationBarColor(ContextCompat.getColor(activity, R.color.ic_launcher_background))
                    .build()
            )
            .setStartAnimations(activity, android.R.anim.fade_in, android.R.anim.fade_out)
            .setExitAnimations(activity, android.R.anim.fade_in, android.R.anim.fade_out)
            .build()

        // Force Chrome Custom Tab (not external browser)
        customTabsIntent.intent.setPackage("com.android.chrome")

        customTabsIntent.launchUrl(activity, Uri.parse(authUrl))
    }

    /**
     * Call this from MainActivity.onNewIntent() when deep link arrives
     */
    fun handleAuthCallback(intent: Intent?): String? {
        val data = intent?.data ?: return null

        // Check if this is our OAuth callback
        if (data.scheme == "ms-xal-00000000402b5324" && data.host == "auth") {
            return data.getQueryParameter("code")
        }
        return null
    }
}
