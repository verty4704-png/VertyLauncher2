package com.verty.launcher.core.account

import android.app.Activity
import android.content.Context
import android.net.Uri
import com.verty.launcher.core.security.SecureStorage
import com.verty.launcher.domain.model.Account
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MicrosoftAuth @Inject constructor(
    @ApplicationContext private val context: Context,
    private val okHttpClient: OkHttpClient,
    private val json: Json,
    private val secureStorage: SecureStorage
) {
    companion object {
        const val CLIENT_ID = "00000000402b5324"
        const val REDIRECT_URI = "ms-xal-00000000402b5324://auth"
        const val AUTH_URL = "https://login.live.com/oauth20_authorize.srf"
        const val TOKEN_URL = "https://login.live.com/oauth20_token.srf"
        const val XBOX_AUTH_URL = "https://user.auth.xboxlive.com/user/authenticate"
        const val XSTS_AUTH_URL = "https://xsts.auth.xboxlive.com/xsts/authorize"
        const val MC_AUTH_URL = "https://api.minecraftservices.com/authentication/login_with_xbox"
        const val MC_PROFILE_URL = "https://api.minecraftservices.com/minecraft/profile"
    }

    private var pendingCodeVerifier: String? = null

    /**
     * STEP 1: Build auth URL and open Custom Tabs
     * Call this when user clicks "Login with Microsoft"
     */
    fun startAuthFlow(activity: Activity) {
        val codeVerifier = generateCodeVerifier()
        pendingCodeVerifier = codeVerifier
        val codeChallenge = generateCodeChallenge(codeVerifier)
        val authUrl = buildAuthUrl(codeChallenge)

        CustomTabsAuth.openAuthPage(activity, authUrl)
    }

    /**
     * STEP 2: Complete auth after receiving code from deep link
     * Call this from MainActivity when Custom Tabs redirects back
     */
    suspend fun completeAuthFromCode(authCode: String): Account.MicrosoftAccount =
        withContext(Dispatchers.IO) {
            val verifier = pendingCodeVerifier 
                ?: throw AuthException("No pending code verifier found")
            pendingCodeVerifier = null

            val msTokens = exchangeCodeForTokens(authCode, verifier)
            val xboxToken = authenticateXboxLive(msTokens.accessToken)
            val xstsToken = authenticateXSTS(xboxToken)
            val mcToken = authenticateMinecraft(xstsToken)
            val profile = getMinecraftProfile(mcToken.accessToken)

            val account = Account.MicrosoftAccount(
                id = profile.id,
                username = profile.name,
                xuid = xstsToken.userXUID,
                accessToken = mcToken.accessToken,
                refreshToken = msTokens.refreshToken,
                expiresAt = System.currentTimeMillis() + (mcToken.expiresIn * 1000)
            )

            secureStorage.store("ms_refresh_${account.id}", msTokens.refreshToken)
            account
        }

    suspend fun refreshToken(account: Account.MicrosoftAccount): Account.MicrosoftAccount =
        withContext(Dispatchers.IO) {
            val refreshToken = secureStorage.retrieve("ms_refresh_${account.id}")
                ?: throw AuthException("No refresh token found")

            val body = FormBody.Builder()
                .add("client_id", CLIENT_ID)
                .add("refresh_token", refreshToken)
                .add("grant_type", "refresh_token")
                .add("redirect_uri", REDIRECT_URI)
                .add("scope", "XboxLive.signin XboxLive.offline_access")
                .build()

            val request = Request.Builder()
                .url(TOKEN_URL)
                .post(body)
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) throw AuthException("Token refresh failed: ${response.code}")

            val tokenResponse = json.decodeFromString<MicrosoftTokenResponse>(response.body!!.string())
            val xboxToken = authenticateXboxLive(tokenResponse.accessToken)
            val xstsToken = authenticateXSTS(xboxToken)
            val mcToken = authenticateMinecraft(xstsToken)
            val profile = getMinecraftProfile(mcToken.accessToken)

            account.copy(
                accessToken = mcToken.accessToken,
                refreshToken = tokenResponse.refreshToken,
                expiresAt = System.currentTimeMillis() + (mcToken.expiresIn * 1000),
                username = profile.name
            )
        }

    private fun generateCodeVerifier(): String {
        val bytes = ByteArray(32)
        SecureRandom().nextBytes(bytes)
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
    }

    private fun generateCodeChallenge(verifier: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(verifier.toByteArray())
        return Base64.getUrlEncoder().withoutPadding().encodeToString(hash)
    }

    private fun buildAuthUrl(codeChallenge: String): String {
        return Uri.parse(AUTH_URL).buildUpon()
            .appendQueryParameter("client_id", CLIENT_ID)
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("redirect_uri", REDIRECT_URI)
            .appendQueryParameter("scope", "XboxLive.signin XboxLive.offline_access")
            .appendQueryParameter("code_challenge", codeChallenge)
            .appendQueryParameter("code_challenge_method", "S256")
            .build()
            .toString()
    }

    private suspend fun exchangeCodeForTokens(code: String, verifier: String): MicrosoftTokenResponse {
        val body = FormBody.Builder()
            .add("client_id", CLIENT_ID)
            .add("code", code)
            .add("code_verifier", verifier)
            .add("grant_type", "authorization_code")
            .add("redirect_uri", REDIRECT_URI)
            .build()

        val request = Request.Builder()
            .url(TOKEN_URL)
            .post(body)
            .build()

        val response = okHttpClient.newCall(request).execute()
        if (!response.isSuccessful) throw AuthException("Token exchange failed: ${response.code}")

        return json.decodeFromString(response.body!!.string())
    }

    private suspend fun authenticateXboxLive(accessToken: String): XboxToken {
        val body = buildString {
            append("{")
            append("\"Properties\":{")
            append("\"AuthMethod\":\"RPS\",")
            append("\"SiteName\":\"user.auth.xboxlive.com\",")
            append("\"RpsTicket\":\"d=$accessToken\"")
            append("},")
            append("\"RelyingParty\":\"http://auth.xboxlive.com\",")
            append("\"TokenType\":\"JWT\"")
            append("}")
        }

        val request = Request.Builder()
            .url(XBOX_AUTH_URL)
            .post(okhttp3.RequestBody.create(okhttp3.MediaType.parse("application/json"), body))
            .header("Accept", "application/json")
            .build()

        val response = okHttpClient.newCall(request).execute()
        if (!response.isSuccessful) throw AuthException("Xbox auth failed: ${response.code}")

        return json.decodeFromString(response.body!!.string())
    }

    private suspend fun authenticateXSTS(xboxToken: XboxToken): XSTSToken {
        val body = buildString {
            append("{")
            append("\"Properties\":{")
            append("\"SandboxId\":\"RETAIL\",")
            append("\"UserTokens\":[\"${xboxToken.token}\"]")
            append("},")
            append("\"RelyingParty\":\"rp://api.minecraftservices.com/\",")
            append("\"TokenType\":\"JWT\"")
            append("}")
        }

        val request = Request.Builder()
            .url(XSTS_AUTH_URL)
            .post(okhttp3.RequestBody.create(okhttp3.MediaType.parse("application/json"), body))
            .header("Accept", "application/json")
            .build()

        val response = okHttpClient.newCall(request).execute()
        if (!response.isSuccessful) throw AuthException("XSTS auth failed: ${response.code}")

        return json.decodeFromString(response.body!!.string())
    }

    private suspend fun authenticateMinecraft(xstsToken: XSTSToken): MinecraftToken {
        val body = buildString {
            append("{")
            append("\"identityToken\":\"XBL3.0 x=${xstsToken.userHash};${xstsToken.token}\"")
            append("}")
        }

        val request = Request.Builder()
            .url(MC_AUTH_URL)
            .post(okhttp3.RequestBody.create(okhttp3.MediaType.parse("application/json"), body))
            .header("Accept", "application/json")
            .build()

        val response = okHttpClient.newCall(request).execute()
        if (!response.isSuccessful) throw AuthException("Minecraft auth failed: ${response.code}")

        return json.decodeFromString(response.body!!.string())
    }

    private suspend fun getMinecraftProfile(accessToken: String): MinecraftProfile {
        val request = Request.Builder()
            .url(MC_PROFILE_URL)
            .header("Authorization", "Bearer $accessToken")
            .header("Accept", "application/json")
            .build()

        val response = okHttpClient.newCall(request).execute()
        if (!response.isSuccessful) throw AuthException("Profile fetch failed: ${response.code}")

        return json.decodeFromString(response.body!!.string())
    }
}

@Serializable
data class MicrosoftTokenResponse(
    val accessToken: String,
    val refreshToken: String,
    val expiresIn: Long,
    val tokenType: String
)

@Serializable
data class XboxToken(
    val token: String,
    val displayClaims: DisplayClaims
) {
    val userXUID: String
        get() = displayClaims.xui.firstOrNull()?.uhs ?: ""
}

@Serializable
data class DisplayClaims(
    val xui: List<XUIClaim>
)

@Serializable
data class XUIClaim(
    val uhs: String,
    val xid: String = ""
)

@Serializable
data class XSTSToken(
    val token: String,
    val displayClaims: DisplayClaims
) {
    val userHash: String
        get() = displayClaims.xui.firstOrNull()?.uhs ?: ""
    val userXUID: String
        get() = displayClaims.xui.firstOrNull()?.xid ?: ""
}

@Serializable
data class MinecraftToken(
    val accessToken: String,
    val expiresIn: Long
)

@Serializable
data class MinecraftProfile(
    val id: String,
    val name: String,
    val skins: List<Skin>? = null,
    val capes: List<Cape>? = null
)

@Serializable
data class Skin(
    val id: String,
    val state: String,
    val url: String,
    val variant: String
)

@Serializable
data class Cape(
    val id: String,
    val state: String,
    val url: String
)

class AuthException(message: String) : Exception(message)
