package com.verty.launcher.core.native

object NativeBridge {
    init {
        System.loadLibrary("verty_native")
    }

    // === System Info ===
    external fun getNativeVersion(): String
    external fun getAvailableMemory(): Long
    external fun trimMemory()
    external fun isArm64Supported(): Boolean
    external fun fastFileHash(path: String): Long
    external fun getNativeHeapSize(): Long
    external fun fastFileIndex(rootPath: String): Array<String>
    external fun installCrashHandler()
    external fun getGpuInfo(): String
    external fun isVulkanSupported(): Boolean
    external fun getGLESVersion(): Int
    external fun hasExtension(extension: String): Boolean
    external fun setSwapInterval(interval: Int)
    external fun createGLContext(majorVersion: Int, minorVersion: Int): Long
    external fun destroyGLContext(contextHandle: Long)

    // === JVM Optimization ===
    external fun buildOptimizedJvmArgs(
        maxMemoryMb: Int,
        useG1GC: Boolean = true,
        useStringDeduplication: Boolean = true,
        aggressiveOpts: Boolean = true
    ): Array<String>

    // === Process Management ===
    external fun setProcessPriority(priority: Int)
    external fun adviseSequentialAccess(path: String)

    // === Input Injection (for LWJGL bridge) ===
    external fun injectMouseMove(deltaX: Double, deltaY: Double)
    external fun injectMouseButton(button: Int, action: Int)
    external fun injectScroll(xOffset: Double, yOffset: Double)
    external fun injectKey(key: Int, action: Int)
    external fun injectChar(codepoint: Int)

    // === GLFW Bridge ===
    external fun glfwInit(): Boolean
    external fun glfwCreateWindow(width: Int, height: Int, title: String): Long
    external fun glfwMakeContextCurrent(window: Long)
    external fun glfwSwapBuffers(window: Long)
    external fun glfwPollEvents()
    external fun glfwSetKeyCallback(window: Long, callback: Long)
    external fun glfwSetMouseButtonCallback(window: Long, callback: Long)
    external fun glfwSetCursorPosCallback(window: Long, callback: Long)
    external fun glfwSetScrollCallback(window: Long, callback: Long)
    external fun glfwSetWindowSizeCallback(window: Long, callback: Long)
    external fun glfwSetWindowShouldClose(window: Long, value: Boolean)
    external fun glfwWindowShouldClose(window: Long): Boolean
    external fun glfwGetCurrentContext(): Long
    external fun glfwSwapInterval(interval: Int)
    external fun glfwGetTime(): Double
    external fun glfwGetPrimaryMonitor(): Long
    external fun glfwGetVideoMode(monitor: Long): Int
    external fun glfwSetWindowMonitor(window: Long, monitor: Long, xpos: Int, ypos: Int, width: Int, height: Int, refreshRate: Int)
    external fun glfwSetWindowPos(window: Long, xpos: Int, ypos: Int)
    external fun glfwSetWindowSize(window: Long, width: Int, height: Int)
    external fun glfwSetWindowTitle(window: Long, title: String)
    external fun glfwSetInputMode(window: Long, mode: Int, value: Int)
    external fun glfwGetInputMode(window: Long, mode: Int): Int
    external fun glfwGetKey(window: Long, key: Int): Int
    external fun glfwGetMouseButton(window: Long, button: Int): Int
    external fun glfwGetCursorPos(window: Long, xpos: DoubleArray, ypos: DoubleArray)
    external fun glfwSetCursorPos(window: Long, xpos: Double, ypos: Double)
    external fun glfwDestroyWindow(window: Long)
    external fun glfwTerminate()
    external fun glfwDefaultWindowHints()
    external fun glfwWindowHint(hint: Int, value: Int)
    external fun glfwWindowHintString(hint: Int, value: String)
    external fun glfwGetFramebufferSize(window: Long, width: IntArray, height: IntArray)
    external fun glfwSetWindowIconifyCallback(window: Long, callback: Long)
    external fun glfwSetWindowFocusCallback(window: Long, callback: Long)
    external fun glfwSetWindowCloseCallback(window: Long, callback: Long)
    external fun glfwSetWindowRefreshCallback(window: Long, callback: Long)
    external fun glfwSetCursorEnterCallback(window: Long, callback: Long)
    external fun glfwSetCharCallback(window: Long, callback: Long)
    external fun glfwSetCharModsCallback(window: Long, callback: Long)
    external fun glfwSetDropCallback(window: Long, callback: Long)
    external fun glfwSetJoystickCallback(callback: Long)
    external fun glfwSetErrorCallback(callback: Long)
    external fun glfwSetMonitorCallback(callback: Long)
    external fun glfwGetWindowContentScale(window: Long, xscale: FloatArray, yscale: FloatArray)
    external fun glfwGetWindowFrameSize(window: Long, left: IntArray, top: IntArray, right: IntArray, bottom: IntArray)
    external fun glfwGetWindowOpacity(window: Long): Float
    external fun glfwSetWindowOpacity(window: Long, opacity: Float)
    external fun glfwRequestWindowAttention(window: Long)
    external fun glfwGetWindowMonitor(window: Long): Long
    external fun glfwIconifyWindow(window: Long)
    external fun glfwRestoreWindow(window: Long)
    external fun glfwMaximizeWindow(window: Long)
    external fun glfwShowWindow(window: Long)
    external fun glfwHideWindow(window: Long)
    external fun glfwFocusWindow(window: Long)
    external fun glfwGetWindowAttrib(window: Long, attrib: Int): Int
    external fun glfwSetWindowAttrib(window: Long, attrib: Int, value: Int)
    external fun glfwSetWindowUserPointer(window: Long, pointer: Long)
    external fun glfwGetWindowUserPointer(window: Long): Long
    external fun glfwSetWindowPosCallback(window: Long, callback: Long)
    external fun glfwSetFramebufferSizeCallback(window: Long, callback: Long)
    external fun glfwSetWindowContentScaleCallback(window: Long, callback: Long)
    external fun glfwGetClipboardString(window: Long): String
    external fun glfwSetClipboardString(window: Long, string: String)
    external fun glfwJoystickPresent(jid: Int): Int
    external fun glfwGetJoystickName(jid: Int): String
    external fun glfwGetJoystickGUID(jid: Int): String
    external fun glfwGetJoystickAxes(jid: Int, count: IntArray): FloatArray
    external fun glfwGetJoystickButtons(jid: Int, count: IntArray): ByteArray
    external fun glfwUpdateGamepadMappings(string: String): Int
    external fun glfwGetGamepadState(jid: Int, state: Long): Boolean
    external fun glfwGetMonitors(count: IntArray): LongArray
    external fun glfwGetMonitorPos(monitor: Long, xpos: IntArray, ypos: IntArray)
    external fun glfwGetMonitorWorkarea(monitor: Long, xpos: IntArray, ypos: IntArray, width: IntArray, height: IntArray)
    external fun glfwGetMonitorPhysicalSize(monitor: Long, widthMM: IntArray, heightMM: IntArray)
    external fun glfwGetMonitorContentScale(monitor: Long, xscale: FloatArray, yscale: FloatArray)
    external fun glfwGetMonitorName(monitor: Long): String
    external fun glfwSetGamma(monitor: Long, gamma: Float)
    external fun glfwGetGammaRamp(monitor: Long): Int
    external fun glfwSetGammaRamp(monitor: Long, ramp: Int)
    external fun glfwGetVideoModes(monitor: Long, count: IntArray): IntArray
    external fun glfwGetError(description: Array<String>): Int
    external fun glfwSetTime(time: Double)
    external fun glfwGetTimerValue(): Long
    external fun glfwGetTimerFrequency(): Long
    external fun glfwWaitEvents()
    external fun glfwWaitEventsTimeout(timeout: Double)
    external fun glfwPostEmptyEvent()
    external fun glfwVulkanSupported(): Int
    external fun glfwGetRequiredInstanceExtensions(count: IntArray): Array<String>
    external fun glfwGetInstanceProcAddress(instance: Long, procname: String): Long
    external fun glfwGetPhysicalDevicePresentationSupport(instance: Long, device: Long, queuefamily: Int): Int
    external fun glfwCreateWindowSurface(instance: Long, window: Long, allocator: Long, surface: LongArray): Int
    external fun glfwInitHint(hint: Int, value: Int)
    external fun glfwGetVersion(major: IntArray, minor: IntArray, rev: IntArray)
    external fun glfwGetVersionString(): String
    external fun glfwGetPrimaryMonitor(): Long
    external fun glfwGetWindowPos(window: Long, xpos: IntArray, ypos: IntArray)
    external fun glfwSetWindowSizeLimits(window: Long, minwidth: Int, minheight: Int, maxwidth: Int, maxheight: Int)
    external fun glfwSetWindowAspectRatio(window: Long, numer: Int, denom: Int)
    external fun glfwSetWindowIcon(window: Long, count: Int, images: Long)
    external fun glfwGetWindowContentScale(window: Long, xscale: FloatArray, yscale: FloatArray)
    external fun glfwGetWindowFrameSize(window: Long, left: IntArray, top: IntArray, right: IntArray, bottom: IntArray)
    external fun glfwSetWindowIconifyCallback(window: Long, callback: Long)
    external fun glfwSetWindowMaximizeCallback(window: Long, callback: Long)
    external fun glfwGetWindowContentScale(window: Long, xscale: FloatArray, yscale: FloatArray)
}
