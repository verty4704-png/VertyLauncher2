package com.verty.launcher.core

import android.content.Context
import android.os.Build
import com.verty.launcher.BuildConfig
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CrashReporter @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val crashDir = File(context.cacheDir, "crashes").apply { mkdirs() }
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US)

    init {
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            val report = generateReport(thread, throwable)
            saveCrash(report)
            // Call previous handler if exists
            (Thread.getDefaultUncaughtExceptionHandler() as? java.lang.Thread.UncaughtExceptionHandler)
                ?.uncaughtException(thread, throwable)
        }
    }

    private fun generateReport(thread: Thread, throwable: Throwable): CrashReport {
        val sw = StringWriter()
        throwable.printStackTrace(PrintWriter(sw))

        return CrashReport(
            timestamp = System.currentTimeMillis(),
            threadName = thread.name,
            exceptionClass = throwable.javaClass.name,
            message = throwable.message ?: "No message",
            stackTrace = sw.toString(),
            deviceInfo = DeviceInfo(
                manufacturer = Build.MANUFACTURER,
                model = Build.MODEL,
                androidVersion = Build.VERSION.RELEASE,
                sdk = Build.VERSION.SDK_INT,
                abi = Build.SUPPORTED_ABIS?.firstOrNull() ?: "unknown"
            ),
            appVersion = BuildConfig.VERSION_NAME,
            buildType = BuildConfig.BUILD_TYPE
        )
    }

    private fun saveCrash(report: CrashReport) {
        val fileName = "crash_${dateFormat.format(Date(report.timestamp))}.json"
        val file = File(crashDir, fileName)
        // Serialize and save
    }

    suspend fun getRecentCrashes(limit: Int = 10): List<CrashReport> = withContext(Dispatchers.IO) {
        crashDir.listFiles()
            ?.sortedByDescending { it.lastModified() }
            ?.take(limit)
            ?.mapNotNull { parseCrashFile(it) }
            ?: emptyList()
    }

    private fun parseCrashFile(file: File): CrashReport? {
        return try {
            // Parse JSON crash report
            null // Simplified
        } catch (_: Exception) {
            null
        }
    }

    suspend fun clearCrashes() = withContext(Dispatchers.IO) {
        crashDir.listFiles()?.forEach { it.delete() }
    }
}

data class CrashReport(
    val timestamp: Long,
    val threadName: String,
    val exceptionClass: String,
    val message: String,
    val stackTrace: String,
    val deviceInfo: DeviceInfo,
    val appVersion: String,
    val buildType: String
)

data class DeviceInfo(
    val manufacturer: String,
    val model: String,
    val androidVersion: String,
    val sdk: Int,
    val abi: String
)
