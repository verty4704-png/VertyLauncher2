package com.verty.launcher.domain.model

import kotlinx.serialization.Serializable

@Serializable
sealed class Account {
    abstract val id: String
    abstract val username: String
    abstract val avatarUrl: String?
    abstract val createdAt: Long

    @Serializable
    data class MicrosoftAccount(
        override val id: String,
        override val username: String,
        override val avatarUrl: String? = null,
        override val createdAt: Long = System.currentTimeMillis(),
        val xuid: String,
        val accessToken: String = "",
        val refreshToken: String = "",
        val expiresAt: Long = 0
    ) : Account()

    @Serializable
    data class OfflineAccount(
        override val id: String,
        override val username: String,
        override val avatarUrl: String? = null,
        override val createdAt: Long = System.currentTimeMillis(),
        val uuid: String
    ) : Account()
}
