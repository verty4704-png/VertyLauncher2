package com.verty.launcher.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.verty.launcher.core.PerformanceMonitor
import com.verty.launcher.data.repository.AccountRepository
import com.verty.launcher.data.repository.InstanceRepository
import com.verty.launcher.domain.model.Account
import com.verty.launcher.domain.model.MinecraftInstance
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val instanceRepository: InstanceRepository,
    private val accountRepository: AccountRepository,
    performanceMonitor: PerformanceMonitor
) : ViewModel() {

    val instances: StateFlow<List<MinecraftInstance>> = instanceRepository.instances
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeAccount: StateFlow<Account?> = accountRepository.activeAccount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val systemMetrics = performanceMonitor.metrics
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    init {
        viewModelScope.launch {
            instanceRepository.loadInstances()
            accountRepository.loadAccounts()
        }
        performanceMonitor.startMonitoring(viewModelScope)
    }

    fun createInstance(instance: MinecraftInstance) {
        viewModelScope.launch {
            instanceRepository.createInstance(instance)
        }
    }

    fun deleteInstance(instanceId: String) {
        viewModelScope.launch {
            instanceRepository.deleteInstance(instanceId)
        }
    }

    fun launchInstance(instanceId: String) {
        // Trigger launch service
    }
}
