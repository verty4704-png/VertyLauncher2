package com.verty.launcher.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface CurseForgeApi {
    @GET("v1/mods/search")
    suspend fun searchMods(
        @Query("gameId") gameId: Int = 432, // Minecraft
        @Query("searchFilter") query: String = "",
        @Query("classId") classId: Int? = null, // 6 = mods, 4471 = modpacks
        @Query("modLoaderType") modLoaderType: Int? = null,
        @Query("gameVersion") gameVersion: String? = null,
        @Query("sortField") sortField: Int = 1,
        @Query("sortOrder") sortOrder: String = "desc",
        @Query("index") index: Int = 0,
        @Query("pageSize") pageSize: Int = 20
    ): CurseForgeSearchResponse

    @GET("v1/mods/{modId}")
    suspend fun getMod(@Path("modId") modId: Int): CurseForgeModResponse

    @GET("v1/mods/{modId}/files")
    suspend fun getModFiles(
        @Path("modId") modId: Int,
        @Query("gameVersion") gameVersion: String? = null,
        @Query("modLoaderType") modLoaderType: Int? = null,
        @Query("pageSize") pageSize: Int = 50
    ): CurseForgeFilesResponse

    @GET("v1/mods/{modId}/files/{fileId}")
    suspend fun getFile(
        @Path("modId") modId: Int,
        @Path("fileId") fileId: Int
    ): CurseForgeFileResponse
}

@Serializable
data class CurseForgeSearchResponse(
    val data: List<CurseForgeMod>
)

@Serializable
data class CurseForgeModResponse(
    val data: CurseForgeMod
)

@Serializable
data class CurseForgeFilesResponse(
    val data: List<CurseForgeFile>
)

@Serializable
data class CurseForgeFileResponse(
    val data: CurseForgeFile
)

@Serializable
data class CurseForgeMod(
    val id: Int,
    val name: String,
    val slug: String,
    val summary: String,
    val downloadCount: Long,
    val latestFilesIndexes: List<CurseForgeFileIndex>,
    val categories: List<CurseForgeCategory>,
    val authors: List<CurseForgeAuthor>,
    val logo: CurseForgeLogo? = null,
    val dateCreated: String,
    val dateModified: String,
    val dateReleased: String
)

@Serializable
data class CurseForgeFileIndex(
    val gameVersion: String,
    val fileId: Int,
    val filename: String,
    val releaseType: Int,
    val modLoader: Int? = null
)

@Serializable
data class CurseForgeFile(
    val id: Int,
    val gameId: Int,
    val modId: Int,
    val isAvailable: Boolean,
    val displayName: String,
    val fileName: String,
    val releaseType: Int,
    val fileStatus: Int,
    val hashes: List<CurseForgeHash>,
    val fileDate: String,
    val fileLength: Long,
    val downloadCount: Long,
    val downloadUrl: String? = null,
    val gameVersions: List<String>,
    val sortableGameVersions: List<SortableGameVersion>,
    val dependencies: List<CurseForgeDependency>,
    val isServerPack: Boolean = false
)

@Serializable
data class CurseForgeHash(
    val value: String,
    val algo: Int // 1 = SHA1, 2 = MD5
)

@Serializable
data class SortableGameVersion(
    val gameVersionName: String,
    val gameVersionPadded: String,
    val gameVersion: String,
    val gameVersionReleaseDate: String,
    val gameVersionTypeId: Int
)

@Serializable
data class CurseForgeDependency(
    val modId: Int,
    val relationType: Int // 1 = embedded, 2 = optional, 3 = required, 4 = tool, 5 = incompatible, 6 = include
)

@Serializable
data class CurseForgeCategory(
    val id: Int,
    val name: String,
    val slug: String
)

@Serializable
data class CurseForgeAuthor(
    val id: Int,
    val name: String,
    val url: String
)

@Serializable
data class CurseForgeLogo(
    val id: Int,
    val modId: Int,
    val title: String,
    val description: String,
    val thumbnailUrl: String,
    val url: String
)
