package com.verty.launcher.data.remote

import com.verty.launcher.domain.model.VersionManifest
import com.verty.launcher.domain.model.VersionInfo
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import retrofit2.http.GET
import retrofit2.http.Url

interface MojangApi {
    @GET("https://launchermeta.mojang.com/mc/game/version_manifest_v2.json")
    suspend fun getVersionManifest(): VersionManifest

    @GET
    suspend fun getVersionJson(@Url url: String): VersionJson

    @GET
    suspend fun getAssetIndex(@Url url: String): AssetIndex
}

@Serializable
data class VersionJson(
    val id: String,
    val type: String,
    val assets: String,
    val assetIndex: AssetIndexInfo,
    val downloads: Downloads,
    val libraries: List<Library>,
    val mainClass: String,
    val minimumLauncherVersion: Int,
    val releaseTime: String,
    val time: String,
    val javaVersion: JavaVersionInfo? = null,
    val logging: JsonObject? = null,
    val arguments: Arguments? = null
)

@Serializable
data class AssetIndexInfo(
    val id: String,
    val sha1: String,
    val size: Long,
    val totalSize: Long,
    val url: String
)

@Serializable
data class Downloads(
    val client: DownloadFile? = null,
    val client_mappings: DownloadFile? = null,
    val server: DownloadFile? = null,
    val server_mappings: DownloadFile? = null
)

@Serializable
data class DownloadFile(
    val sha1: String,
    val size: Long,
    val url: String
)

@Serializable
data class Library(
    val downloads: LibraryDownloads,
    val name: String,
    val rules: List<Rule>? = null,
    val natives: Map<String, String>? = null,
    val extract: ExtractInfo? = null
)

@Serializable
data class LibraryDownloads(
    val artifact: Artifact? = null,
    val classifiers: Map<String, Artifact>? = null
)

@Serializable
data class Artifact(
    val path: String,
    val sha1: String,
    val size: Long,
    val url: String
)

@Serializable
data class Rule(
    val action: String,
    val os: OsRule? = null
)

@Serializable
data class OsRule(
    val name: String? = null,
    val arch: String? = null
)

@Serializable
data class ExtractInfo(
    val exclude: List<String>? = null
)

@Serializable
data class JavaVersionInfo(
    val majorVersion: Int,
    val component: String
)

@Serializable
data class Arguments(
    val game: List<ArgumentElement> = emptyList(),
    val jvm: List<ArgumentElement> = emptyList()
)

@Serializable
sealed class ArgumentElement {
    @Serializable
    data class Value(val value: String) : ArgumentElement()
    @Serializable
    data class Conditional(
        val rules: List<Rule>,
        val value: List<String>
    ) : ArgumentElement()
}

@Serializable
data class AssetIndex(
    val objects: Map<String, AssetObject>
)

@Serializable
data class AssetObject(
    val hash: String,
    val size: Long
)
