package com.verty.launcher.core.download

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VertyDownloadManager @Inject constructor(
    private val okHttpClient: OkHttpClient
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val maxConcurrent = Semaphore(6)
    private val activeJobs = mutableMapOf<String, Job>()

    private val _globalProgress = MutableStateFlow(0f)
    val globalProgress: StateFlow<Float> = _globalProgress.asStateFlow()

    private val _downloadEvents = Channel<DownloadEvent>(Channel.BUFFERED)
    val downloadEvents: Flow<DownloadEvent> = _downloadEvents.receiveAsFlow()

    private val _queue = MutableStateFlow<List<DownloadTask>>(emptyList())
    val queue: StateFlow<List<DownloadTask>> = _queue.asStateFlow()

    fun enqueue(tasks: List<DownloadTask>) {
        val current = _queue.value.toMutableList()
        current.addAll(tasks.filter { t -> current.none { it.id == t.id } })
        _queue.value = current
        processQueue()
    }

    fun enqueue(task: DownloadTask) = enqueue(listOf(task))

    fun cancel(taskId: String) {
        activeJobs[taskId]?.cancel()
        activeJobs.remove(taskId)
        updateTaskStatus(taskId, DownloadStatus.CANCELLED)
    }

    fun pause(taskId: String) {
        activeJobs[taskId]?.cancel()
        activeJobs.remove(taskId)
        updateTaskStatus(taskId, DownloadStatus.PAUSED)
    }

    fun resume(taskId: String) {
        val task = _queue.value.find { it.id == taskId } ?: return
        if (task.status == DownloadStatus.PAUSED || task.status == DownloadStatus.FAILED) {
            updateTaskStatus(taskId, DownloadStatus.QUEUED)
            processQueue()
        }
    }

    private fun processQueue() {
        val pending = _queue.value.filter { it.status == DownloadStatus.QUEUED }
        pending.forEach { task ->
            if (activeJobs.containsKey(task.id)) return@forEach
            val job = scope.launch {
                maxConcurrent.withPermit {
                    executeDownload(task)
                }
            }
            activeJobs[task.id] = job
        }
    }

    private suspend fun executeDownload(task: DownloadTask) {
        updateTaskStatus(task.id, DownloadStatus.DOWNLOADING)
        val destFile = File(task.destinationPath)
        destFile.parentFile?.mkdirs()

        val existingSize = if (destFile.exists() && task.supportsResume) destFile.length() else 0L

        try {
            val request = Request.Builder()
                .url(task.url)
                .apply {
                    if (existingSize > 0 && task.supportsResume) {
                        header("Range", "bytes=$existingSize-")
                    }
                }
                .build()

            okHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful && response.code != 206) {
                    throw DownloadException("HTTP ${response.code}")
                }

                val body = response.body ?: throw DownloadException("Empty body")
                val totalBytes = if (existingSize > 0) {
                    existingSize + (body.contentLength().takeIf { it > 0 } ?: task.expectedSize)
                } else {
                    body.contentLength().takeIf { it > 0 } ?: task.expectedSize
                }

                val mode = if (existingSize > 0 && response.code == 206) "rws" else "rws"
                RandomAccessFile(destFile, mode).use { raf ->
                    if (existingSize > 0 && response.code == 206) {
                        raf.seek(existingSize)
                    } else {
                        raf.setLength(0)
                    }

                    val buffer = ByteArray(8192)
                    var downloaded = existingSize
                    var lastProgressUpdate = 0L

                    body.byteStream().use { input ->
                        var read: Int
                        while (input.read(buffer).also { read = it } != -1) {
                            raf.write(buffer, 0, read)
                            downloaded += read

                            val now = System.currentTimeMillis()
                            if (now - lastProgressUpdate > 100) {
                                val progress = if (totalBytes > 0) downloaded.toFloat() / totalBytes else 0f
                                updateTaskProgress(task.id, progress, downloaded, totalBytes)
                                lastProgressUpdate = now
                            }
                        }
                    }
                }

                // Verify checksum if provided
                if (task.expectedHash != null) {
                    val actualHash = calculateSha256(destFile)
                    if (!actualHash.equals(task.expectedHash, ignoreCase = true)) {
                        destFile.delete()
                        throw DownloadException("Hash mismatch")
                    }
                }

                updateTaskStatus(task.id, DownloadStatus.COMPLETED)
                _downloadEvents.send(DownloadEvent.Completed(task.id, destFile))
            }
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) {
                updateTaskStatus(task.id, DownloadStatus.PAUSED)
            } else {
                updateTaskStatus(task.id, DownloadStatus.FAILED)
                _downloadEvents.send(DownloadEvent.Failed(task.id, e.message ?: "Unknown"))
            }
        } finally {
            activeJobs.remove(task.id)
            updateGlobalProgress()
            processQueue()
        }
    }

    private fun updateTaskStatus(taskId: String, status: DownloadStatus) {
        _queue.value = _queue.value.map {
            if (it.id == taskId) it.copy(status = status) else it
        }
    }

    private fun updateTaskProgress(taskId: String, progress: Float, downloaded: Long, total: Long) {
        _queue.value = _queue.value.map {
            if (it.id == taskId) it.copy(progress = progress, downloadedBytes = downloaded, totalBytes = total) else it
        }
        updateGlobalProgress()
    }

    private fun updateGlobalProgress() {
        val tasks = _queue.value.filter { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.QUEUED }
        if (tasks.isEmpty()) {
            _globalProgress.value = 1f
            return
        }
        val total = tasks.sumOf { it.totalBytes.coerceAtLeast(1) }
        val downloaded = tasks.sumOf { it.downloadedBytes }
        _globalProgress.value = if (total > 0) downloaded.toFloat() / total else 0f
    }

    private fun calculateSha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            var read: Int
            while (input.read(buffer).also { read = it } != -1) {
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun shutdown() {
        activeJobs.values.forEach { it.cancel() }
        activeJobs.clear()
        scope.cancel()
    }
}

// Domain models
data class DownloadTask(
    val id: String,
    val url: String,
    val destinationPath: String,
    val expectedSize: Long = 0,
    val expectedHash: String? = null,
    val supportsResume: Boolean = true,
    val priority: Int = 0,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val progress: Float = 0f,
    val downloadedBytes: Long = 0,
    val totalBytes: Long = 0,
    val metadata: Map<String, String> = emptyMap()
)

enum class DownloadStatus { QUEUED, DOWNLOADING, PAUSED, COMPLETED, FAILED, CANCELLED }

sealed class DownloadEvent {
    data class Progress(val taskId: String, val progress: Float) : DownloadEvent()
    data class Completed(val taskId: String, val file: File) : DownloadEvent()
    data class Failed(val taskId: String, val error: String) : DownloadEvent()
}

class DownloadException(message: String) : Exception(message)
