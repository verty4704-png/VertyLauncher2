package com.verty.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import com.verty.launcher.core.account.CustomTabsAuth
import com.verty.launcher.core.account.MicrosoftAuth
import com.verty.launcher.ui.navigation.VertyNavHost
import com.verty.launcher.ui.theme.VertyTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var microsoftAuth: MicrosoftAuth

    @OptIn(ExperimentalAnimationApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)

        splashScreen.setKeepOnScreenCondition { false }

        // Handle OAuth callback if app was opened from deep link
        handleAuthCallback(intent)

        setContent {
            VertyTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    VertyNavHost()
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Handle OAuth callback when app is already running
        handleAuthCallback(intent)
    }

    private fun handleAuthCallback(intent: Intent?) {
        val authCode = CustomTabsAuth.handleAuthCallback(intent)
        if (authCode != null) {
            // Complete the OAuth flow
            lifecycleScope.launch {
                try {
                    val account = microsoftAuth.completeAuthFromCode(authCode)
                    // TODO: Save account to repository, navigate to dashboard
                } catch (e: Exception) {
                    // TODO: Show error to user
                }
            }
        }
    }
}
