package com.verty.launcher.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.verty.launcher.MainActivity
import com.verty.launcher.R
import com.verty.launcher.core.download.DownloadTask
import com.verty.launcher.core.download.VertyDownloadManager
import com.verty.launcher.core.download.DownloadStatus
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class DownloadService : Service() {

    @Inject
    lateinit var downloadManager: VertyDownloadManager

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val notificationManager by lazy {
        getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    companion object {
        const val CHANNEL_ID = "verty_downloads"
        const val NOTIFICATION_ID = 2001
        const val ACTION_ENQUEUE = "com.verty.launcher.ACTION_ENQUEUE"
        const val EXTRA_TASKS = "tasks"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        serviceScope.launch {
            downloadManager.queue.collectLatest { tasks ->
                val active = tasks.filter { it.status == DownloadStatus.DOWNLOADING }
                if (active.isNotEmpty()) {
                    updateNotification(active)
                } else {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val tasks = intent?.getParcelableArrayListExtra<DownloadTask>(EXTRA_TASKS)
        tasks?.let { downloadManager.enqueue(it) }
        return START_NOT_STICKY
    }

    private fun updateNotification(activeTasks: List<DownloadTask>) {
        val totalProgress = activeTasks.sumOf { it.downloadedBytes }
        val totalSize = activeTasks.sumOf { it.totalBytes.coerceAtLeast(1) }
        val progress = (totalProgress * 100 / totalSize).toInt()

        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Downloading ${activeTasks.size} files")
            .setContentText("$progress% complete")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setProgress(100, progress, false)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Downloads",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background file downloads"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }
}
