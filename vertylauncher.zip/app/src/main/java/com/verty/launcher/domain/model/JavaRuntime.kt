package com.verty.launcher.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class JavaRuntime(
    val id: String,
    val version: Int,
    val vendor: String,
    val path: String,
    val isInstalled: Boolean = false,
    val downloadUrl: String? = null,
    val size: Long = 0,
    val checksum: String? = null,
    val isDefault: Boolean = false
)
