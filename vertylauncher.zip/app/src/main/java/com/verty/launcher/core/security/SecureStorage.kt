package com.verty.launcher.core.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.crypto.tink.Aead
import com.google.crypto.tink.KeysetHandle
import com.google.crypto.tink.aead.AeadKeyTemplates
import com.google.crypto.tink.config.TinkConfig
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.charset.StandardCharsets
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SecureStorage @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val masterKey: MasterKey by lazy {
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    private val encryptedPrefs: SharedPreferences by lazy {
        EncryptedSharedPreferences.create(
            context,
            "verty_secure_storage",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    init {
        TinkConfig.register()
    }

    suspend fun store(key: String, value: String) = withContext(Dispatchers.IO) {
        encryptedPrefs.edit().putString(key, value).apply()
    }

    suspend fun retrieve(key: String): String? = withContext(Dispatchers.IO) {
        encryptedPrefs.getString(key, null)
    }

    suspend fun remove(key: String) = withContext(Dispatchers.IO) {
        encryptedPrefs.edit().remove(key).apply()
    }

    suspend fun clear() = withContext(Dispatchers.IO) {
        encryptedPrefs.edit().clear().apply()
    }

    fun storeSync(key: String, value: String) {
        encryptedPrefs.edit().putString(key, value).apply()
    }

    fun retrieveSync(key: String): String? =
        encryptedPrefs.getString(key, null)
}
