package com.verty.launcher.data.repository

import android.content.Context
import com.verty.launcher.core.download.DownloadTask
import com.verty.launcher.core.download.VertyDownloadManager
import com.verty.launcher.data.remote.MojangApi
import com.verty.launcher.data.remote.VersionJson
import com.verty.launcher.domain.model.VersionInfo
import com.verty.launcher.domain.model.VersionManifest
import com.verty.launcher.util.ScopedStorageHelper
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VersionRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val mojangApi: MojangApi,
    private val downloadManager: VertyDownloadManager
) {
    private val _manifest = MutableStateFlow<VersionManifest?>(null)
    val manifest: Flow<VersionManifest?> = _manifest.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: Flow<Boolean> = _isLoading.asStateFlow()

    private val versionsDir = ScopedStorageHelper.getVersionsDir(context)
    private val assetsDir = ScopedStorageHelper.getAssetsDir(context)
    private val librariesDir = ScopedStorageHelper.getLibrariesDir(context)

    suspend fun fetchVersionManifest() = withContext(Dispatchers.IO) {
        _isLoading.value = true
        try {
            val manifest = mojangApi.getVersionManifest()
            _manifest.value = manifest
            manifest
        } finally {
            _isLoading.value = false
        }
    }

    suspend fun getVersionJson(versionId: String): VersionJson? = withContext(Dispatchers.IO) {
        val cachedFile = File(versionsDir, "$versionId/$versionId.json")
        if (cachedFile.exists()) {
            return@withContext try {
                kotlinx.serialization.json.Json.decodeFromString(
                    com.verty.launcher.data.remote.VersionJson.serializer(),
                    cachedFile.readText()
                )
            } catch (_: Exception) { null }
        }

        val manifest = _manifest.value ?: fetchVersionManifest()
        val versionInfo = manifest.versions.find { it.id == versionId } ?: return@withContext null

        val versionJson = mojangApi.getVersionJson(versionInfo.url)
        cachedFile.parentFile?.mkdirs()
        cachedFile.writeText(
            kotlinx.serialization.json.Json.encodeToString(
                com.verty.launcher.data.remote.VersionJson.serializer(),
                versionJson
            )
        )
        versionJson
    }

    suspend fun downloadClientJar(versionId: String, versionJson: VersionJson) {
        val clientDownload = versionJson.downloads.client ?: return
        val destFile = File(versionsDir, "$versionId/$versionId.jar")

        val task = DownloadTask(
            id = "client-$versionId",
            url = clientDownload.url,
            destinationPath = destFile.absolutePath,
            expectedSize = clientDownload.size,
            expectedHash = clientDownload.sha1,
            metadata = mapOf("type" to "client_jar", "version" to versionId)
        )
        downloadManager.enqueue(task)
    }

    suspend fun downloadAssetIndex(versionJson: VersionJson) {
        val assetIndex = versionJson.assetIndex
        val destFile = File(assetsDir, "indexes/${assetIndex.id}.json")

        val task = DownloadTask(
            id = "asset-index-${assetIndex.id}",
            url = assetIndex.url,
            destinationPath = destFile.absolutePath,
            expectedSize = assetIndex.size,
            expectedHash = assetIndex.sha1,
            metadata = mapOf("type" to "asset_index")
        )
        downloadManager.enqueue(task)
    }

    suspend fun downloadAssets(versionJson: VersionJson) {
        val assetIndexFile = File(assetsDir, "indexes/${versionJson.assetIndex.id}.json")
        if (!assetIndexFile.exists()) {
            downloadAssetIndex(versionJson)
            return
        }

        val assetIndex = kotlinx.serialization.json.Json.decodeFromString(
            com.verty.launcher.data.remote.AssetIndex.serializer(),
            assetIndexFile.readText()
        )

        val tasks = assetIndex.objects.map { (path, obj) ->
            val hashPrefix = obj.hash.take(2)
            val url = "https://resources.download.minecraft.net/$hashPrefix/${obj.hash}"
            val destPath = File(assetsDir, "objects/$hashPrefix/${obj.hash}").absolutePath

            DownloadTask(
                id = "asset-${obj.hash}",
                url = url,
                destinationPath = destPath,
                expectedSize = obj.size,
                expectedHash = obj.hash,
                metadata = mapOf("type" to "asset", "path" to path)
            )
        }

        downloadManager.enqueue(tasks)
    }

    suspend fun downloadLibraries(versionJson: VersionJson) {
        val tasks = versionJson.libraries.mapNotNull { lib ->
            val artifact = lib.downloads.artifact ?: return@mapNotNull null
            val rules = lib.rules
            if (rules != null && !isRuleAllowed(rules)) return@mapNotNull null

            val destPath = File(librariesDir, artifact.path).absolutePath
            DownloadTask(
                id = "lib-${lib.name}",
                url = artifact.url,
                destinationPath = destPath,
                expectedSize = artifact.size,
                expectedHash = artifact.sha1,
                metadata = mapOf("type" to "library", "name" to lib.name)
            )
        }

        downloadManager.enqueue(tasks)
    }

    private fun isRuleAllowed(rules: List<com.verty.launcher.data.remote.Rule>): Boolean {
        var allowed = true
        for (rule in rules) {
            val osMatch = rule.os?.name == null || rule.os.name == "linux" || rule.os.name == "android"
            if (osMatch) {
                allowed = rule.action == "allow"
            }
        }
        return allowed
    }

    suspend fun installVersion(versionId: String) {
        val versionJson = getVersionJson(versionId) ?: throw IllegalStateException("Version not found")

        downloadClientJar(versionId, versionJson)
        downloadAssetIndex(versionJson)
        downloadLibraries(versionJson)
    }

    fun isVersionInstalled(versionId: String): Boolean {
        val jarFile = File(versionsDir, "$versionId/$versionId.jar")
        val jsonFile = File(versionsDir, "$versionId/$versionId.json")
        return jarFile.exists() && jsonFile.exists()
    }

    fun getVersionDir(versionId: String): File = File(versionsDir, versionId)
}
