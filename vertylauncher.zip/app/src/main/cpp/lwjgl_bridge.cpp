#include <jni.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <vector>
#include <map>
#include <mutex>

#define LOG_TAG "VertyLWJGL"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// === Input State ===
struct InputState {
    double mouseX = 0.0;
    double mouseY = 0.0;
    bool mouseButtons[8] = {false};
    bool keys[GLFW_KEY_LAST + 1] = {false};
    double scrollX = 0.0;
    double scrollY = 0.0;
};

static InputState g_input;
static std::mutex g_inputMutex;

// === JNI Input Injection ===
extern "C" {

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_injectMouseMove(JNIEnv* env, jobject thiz, 
                                                                    jdouble deltaX, jdouble deltaY) {
    std::lock_guard<std::mutex> lock(g_inputMutex);
    g_input.mouseX += deltaX;
    g_input.mouseY += deltaY;
    LOGI("Mouse move: %.2f, %.2f", g_input.mouseX, g_input.mouseY);
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_injectMouseButton(JNIEnv* env, jobject thiz,
                                                                    jint button, jint action) {
    std::lock_guard<std::mutex> lock(g_inputMutex);
    if (button >= 0 && button < 8) {
        g_input.mouseButtons[button] = (action == 1); // GLFW_PRESS = 1
    }
    LOGI("Mouse button %d: %s", button, action == 1 ? "press" : "release");
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_injectScroll(JNIEnv* env, jobject thiz,
                                                                 jdouble xOffset, jdouble yOffset) {
    std::lock_guard<std::mutex> lock(g_inputMutex);
    g_input.scrollX += xOffset;
    g_input.scrollY += yOffset;
    LOGI("Scroll: %.2f, %.2f", xOffset, yOffset);
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_injectKey(JNIEnv* env, jobject thiz,
                                                            jint key, jint action) {
    std::lock_guard<std::mutex> lock(g_inputMutex);
    if (key >= 0 && key <= GLFW_KEY_LAST) {
        g_input.keys[key] = (action == 1);
    }
    LOGI("Key %d: %s", key, action == 1 ? "press" : "release");
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_injectChar(JNIEnv* env, jobject thiz,
                                                               jint codepoint) {
    LOGI("Char: %c", (char)codepoint);
}

} // extern "C"
