#include <jni.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <string>
#include <map>

#define LOG_TAG "VertyGLFW"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Fake window structure
struct AndroidWindow {
    int width = 1280;
    int height = 720;
    std::string title = "Minecraft";
    bool shouldClose = false;
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
};

static std::map<long, AndroidWindow*> g_windows;
static long g_nextWindowId = 1;
static AndroidWindow* g_currentWindow = nullptr;

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwInit(JNIEnv* env, jobject thiz) {
    LOGI("GLFW initialized for Android");
    return JNI_TRUE;
}

JNIEXPORT jlong JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwCreateWindow(JNIEnv* env, jobject thiz,
                                                                    jint width, jint height,
                                                                    jstring title) {
    const char* cTitle = env->GetStringUTFChars(title, nullptr);

    AndroidWindow* window = new AndroidWindow();
    window->width = width;
    window->height = height;
    window->title = std::string(cTitle);

    // In real implementation, this would connect to Android SurfaceView
    // For now, create a fake window handle
    long windowId = g_nextWindowId++;
    g_windows[windowId] = window;

    env->ReleaseStringUTFChars(title, cTitle);
    LOGI("Created window %ld: %dx%d '%s'", windowId, width, height, window->title.c_str());
    return windowId;
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwMakeContextCurrent(JNIEnv* env, jobject thiz,
                                                                          jlong window) {
    auto it = g_windows.find(window);
    if (it != g_windows.end()) {
        g_currentWindow = it->second;
        LOGI("Context current for window %ld", window);
    }
}

JNIEXPORT jlong JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwGetCurrentContext(JNIEnv* env, jobject thiz) {
    for (auto& pair : g_windows) {
        if (pair.second == g_currentWindow) {
            return pair.first;
        }
    }
    return 0;
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwSwapBuffers(JNIEnv* env, jobject thiz,
                                                                    jlong window) {
    // In real implementation, this would call eglSwapBuffers
    // For now, just log
    // eglSwapBuffers(g_currentWindow->display, g_currentWindow->surface);
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwSwapInterval(JNIEnv* env, jobject thiz,
                                                                    jint interval) {
    if (g_currentWindow && g_currentWindow->display != EGL_NO_DISPLAY) {
        eglSwapInterval(g_currentWindow->display, interval);
    }
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwPollEvents(JNIEnv* env, jobject thiz) {
    // Android events are handled in Java layer
    // This is called by Minecraft every frame
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwSetWindowShouldClose(JNIEnv* env, jobject thiz,
                                                                            jlong window, jboolean value) {
    auto it = g_windows.find(window);
    if (it != g_windows.end()) {
        it->second->shouldClose = value;
    }
}

JNIEXPORT jboolean JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwWindowShouldClose(JNIEnv* env, jobject thiz,
                                                                          jlong window) {
    auto it = g_windows.find(window);
    if (it != g_windows.end()) {
        return it->second->shouldClose ? JNI_TRUE : JNI_FALSE;
    }
    return JNI_FALSE;
}

JNIEXPORT jdouble JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwGetTime(JNIEnv* env, jobject thiz) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwSetWindowSize(JNIEnv* env, jobject thiz,
                                                                      jlong window, jint width, jint height) {
    auto it = g_windows.find(window);
    if (it != g_windows.end()) {
        it->second->width = width;
        it->second->height = height;
    }
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwSetWindowTitle(JNIEnv* env, jobject thiz,
                                                                      jlong window, jstring title) {
    const char* cTitle = env->GetStringUTFChars(title, nullptr);
    auto it = g_windows.find(window);
    if (it != g_windows.end()) {
        it->second->title = std::string(cTitle);
    }
    env->ReleaseStringUTFChars(title, cTitle);
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwDestroyWindow(JNIEnv* env, jobject thiz,
                                                                       jlong window) {
    auto it = g_windows.find(window);
    if (it != g_windows.end()) {
        delete it->second;
        g_windows.erase(it);
        LOGI("Destroyed window %ld", window);
    }
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwTerminate(JNIEnv* env, jobject thiz) {
    for (auto& pair : g_windows) {
        delete pair.second;
    }
    g_windows.clear();
    LOGI("GLFW terminated");
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwDefaultWindowHints(JNIEnv* env, jobject thiz) {
    // No-op on Android
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwWindowHint(JNIEnv* env, jobject thiz,
                                                                    jint hint, jint value) {
    // No-op on Android — we control the context
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwGetFramebufferSize(JNIEnv* env, jobject thiz,
                                                                            jlong window, jintArray width, jintArray height) {
    auto it = g_windows.find(window);
    if (it != g_windows.end()) {
        jint w = it->second->width;
        jint h = it->second->height;
        env->SetIntArrayRegion(width, 0, 1, &w);
        env->SetIntArrayRegion(height, 0, 1, &h);
    }
}

// Stub callbacks — in production these would call Java methods
JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwSetKeyCallback(JNIEnv* env, jobject thiz,
                                                                       jlong window, jlong callback) {
    // Store callback reference
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwSetMouseButtonCallback(JNIEnv* env, jobject thiz,
                                                                                jlong window, jlong callback) {
    // Store callback reference
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwSetCursorPosCallback(JNIEnv* env, jobject thiz,
                                                                               jlong window, jlong callback) {
    // Store callback reference
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwSetScrollCallback(JNIEnv* env, jobject thiz,
                                                                              jlong window, jlong callback) {
    // Store callback reference
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwSetWindowSizeCallback(JNIEnv* env, jobject thiz,
                                                                                 jlong window, jlong callback) {
    // Store callback reference
}

JNIEXPORT jint JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwGetInputMode(JNIEnv* env, jobject thiz,
                                                                     jlong window, jint mode) {
    return 0; // Default
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwSetInputMode(JNIEnv* env, jobject thiz,
                                                                     jlong window, jint mode, jint value) {
    // No-op on Android
}

JNIEXPORT jint JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwGetKey(JNIEnv* env, jobject thiz,
                                                                 jlong window, jint key) {
    // Return key state from input handler
    return GLFW_RELEASE;
}

JNIEXPORT jint JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwGetMouseButton(JNIEnv* env, jobject thiz,
                                                                         jlong window, jint button) {
    // Return mouse state from input handler
    return GLFW_RELEASE;
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwGetCursorPos(JNIEnv* env, jobject thiz,
                                                                       jlong window, jdoubleArray xpos, jdoubleArray ypos) {
    // Return current mouse position
    double x = 0.0, y = 0.0;
    env->SetDoubleArrayRegion(xpos, 0, 1, &x);
    env->SetDoubleArrayRegion(ypos, 0, 1, &y);
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwSetCursorPos(JNIEnv* env, jobject thiz,
                                                                       jlong window, jdouble xpos, jdouble ypos) {
    // No-op on Android
}

JNIEXPORT jlong JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwGetPrimaryMonitor(JNIEnv* env, jobject thiz) {
    return 1; // Fake monitor handle
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwGetMonitorPos(JNIEnv* env, jobject thiz,
                                                                        jlong monitor, jintArray xpos, jintArray ypos) {
    jint x = 0, y = 0;
    env->SetIntArrayRegion(xpos, 0, 1, &x);
    env->SetIntArrayRegion(ypos, 0, 1, &y);
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwGetVideoMode(JNIEnv* env, jobject thiz,
                                                                      jlong monitor) {
    // Return current display mode
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_glfwSetWindowMonitor(JNIEnv* env, jobject thiz,
                                                                           jlong window, jlong monitor,
                                                                           jint xpos, jint ypos,
                                                                           jint width, jint height,
                                                                           jint refreshRate) {
    // No-op on Android — fullscreen handled by Activity
}

} // extern "C"
