#include <jni.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <dlfcn.h>
#include <string>

#define LOG_TAG "VertyRenderer"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_verty_launcher_core_native_NativeBridge_getGpuInfo(JNIEnv* env, jobject thiz) {
    const char* vendor = reinterpret_cast<const char*>(glGetString(GL_VENDOR));
    const char* renderer = reinterpret_cast<const char*>(glGetString(GL_RENDERER));
    const char* version = reinterpret_cast<const char*>(glGetString(GL_VERSION));
    const char* glslVersion = reinterpret_cast<const char*>(glGetString(GL_SHADING_LANGUAGE_VERSION));

    std::string info = std::string("Vendor: ") + (vendor ? vendor : "Unknown") +
                       "; Renderer: " + (renderer ? renderer : "Unknown") +
                       "; GL Version: " + (version ? version : "Unknown") +
                       "; GLSL: " + (glslVersion ? glslVersion : "Unknown");

    return env->NewStringUTF(info.c_str());
}

JNIEXPORT jboolean JNICALL
Java_com_verty_launcher_core_native_NativeBridge_isVulkanSupported(JNIEnv* env, jobject thiz) {
    void* vulkanLib = dlopen("libvulkan.so", RTLD_NOW | RTLD_LOCAL);
    if (vulkanLib) {
        dlclose(vulkanLib);
        return JNI_TRUE;
    }
    return JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_com_verty_launcher_core_native_NativeBridge_getGLESVersion(JNIEnv* env, jobject thiz) {
    const char* version = reinterpret_cast<const char*>(glGetString(GL_VERSION));
    if (version) {
        std::string verStr(version);
        // Parse "OpenGL ES 3.2 ..." -> return 32
        size_t pos = verStr.find("OpenGL ES ");
        if (pos != std::string::npos) {
            float ver = std::stof(verStr.substr(pos + 10));
            return static_cast<jint>(ver * 10);
        }
    }
    return 20; // Default ES 2.0
}

JNIEXPORT jboolean JNICALL
Java_com_verty_launcher_core_native_NativeBridge_hasExtension(JNIEnv* env, jobject thiz, jstring extName) {
    const char* cExtName = env->GetStringUTFChars(extName, nullptr);
    const char* extensions = reinterpret_cast<const char*>(glGetString(GL_EXTENSIONS));
    jboolean result = JNI_FALSE;

    if (extensions) {
        std::string extList(extensions);
        if (extList.find(cExtName) != std::string::npos) {
            result = JNI_TRUE;
        }
    }

    env->ReleaseStringUTFChars(extName, cExtName);
    return result;
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_setSwapInterval(JNIEnv* env, jobject thiz, jint interval) {
    EGLDisplay display = eglGetCurrentDisplay();
    EGLSurface surface = eglGetCurrentSurface(EGL_DRAW);

    if (display != EGL_NO_DISPLAY && surface != EGL_NO_SURFACE) {
        eglSwapInterval(display, interval);
        LOGI("Swap interval set to %d", interval);
    }
}

JNIEXPORT jlong JNICALL
Java_com_verty_launcher_core_native_NativeBridge_createGLContext(JNIEnv* env, jobject thiz, 
                                                                   jint majorVersion, 
                                                                   jint minorVersion) {
    // Create a shared EGL context for Minecraft LWJGL bridge
    EGLDisplay display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display == EGL_NO_DISPLAY) {
        LOGE("Failed to get EGL display");
        return 0;
    }

    EGLint major, minor;
    if (!eglInitialize(display, &major, &minor)) {
        LOGE("Failed to initialize EGL");
        return 0;
    }

    EGLint attribs[] = {
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT | EGL_PBUFFER_BIT,
        EGL_BLUE_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_RED_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 24,
        EGL_STENCIL_SIZE, 8,
        EGL_NONE
    };

    EGLConfig config;
    EGLint numConfigs;
    if (!eglChooseConfig(display, attribs, &config, 1, &numConfigs) || numConfigs < 1) {
        LOGE("Failed to choose EGL config");
        return 0;
    }

    EGLint contextAttribs[] = {
        EGL_CONTEXT_CLIENT_VERSION, majorVersion,
        EGL_NONE
    };

    EGLContext context = eglCreateContext(display, config, EGL_NO_CONTEXT, contextAttribs);
    if (context == EGL_NO_CONTEXT) {
        LOGE("Failed to create EGL context");
        return 0;
    }

    LOGI("Created GLES %d.%d context", majorVersion, minorVersion);
    return reinterpret_cast<jlong>(context);
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_destroyGLContext(JNIEnv* env, jobject thiz, jlong contextHandle) {
    EGLContext context = reinterpret_cast<EGLContext>(contextHandle);
    EGLDisplay display = eglGetCurrentDisplay();

    if (display != EGL_NO_DISPLAY && context != EGL_NO_CONTEXT) {
        eglDestroyContext(display, context);
        LOGI("EGL context destroyed");
    }
}

} // extern "C"
