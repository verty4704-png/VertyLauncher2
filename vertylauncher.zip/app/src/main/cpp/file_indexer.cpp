#include <jni.h>
#include <android/log.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string>
#include <vector>
#include <thread>
#include <future>

#define LOG_TAG "VertyIndexer"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" {

struct FileEntry {
    std::string path;
    jlong size;
    jlong modified;
};

static void scanDirectory(const std::string& path, std::vector<FileEntry>& entries) {
    DIR* dir = opendir(path.c_str());
    if (!dir) return;

    struct dirent* entry;
    while ((entry = readdir(dir)) != nullptr) {
        if (entry->d_name[0] == '.') continue;

        std::string fullPath = path + "/" + entry->d_name;
        struct stat st;
        if (stat(fullPath.c_str(), &st) == 0) {
            if (S_ISDIR(st.st_mode)) {
                scanDirectory(fullPath, entries);
            } else {
                entries.push_back({fullPath, static_cast<jlong>(st.st_size), static_cast<jlong>(st.st_mtime)});
            }
        }
    }
    closedir(dir);
}

JNIEXPORT jobjectArray JNICALL
Java_com_verty_launcher_core_native_NativeBridge_fastFileIndex(
    JNIEnv* env,
    jobject thiz,
    jstring rootPath
) {
    const char* cPath = env->GetStringUTFChars(rootPath, nullptr);
    std::string root(cPath);
    env->ReleaseStringUTFChars(rootPath, cPath);

    std::vector<FileEntry> entries;
    scanDirectory(root, entries);

    // Create result array: [path, size, modified] triplets
    jclass stringClass = env->FindClass("java/lang/String");
    jobjectArray result = env->NewObjectArray(entries.size() * 3, stringClass, nullptr);

    for (size_t i = 0; i < entries.size(); i++) {
        env->SetObjectArrayElement(result, i * 3, env->NewStringUTF(entries[i].path.c_str()));
        env->SetObjectArrayElement(result, i * 3 + 1, env->NewStringUTF(std::to_string(entries[i].size).c_str()));
        env->SetObjectArrayElement(result, i * 3 + 2, env->NewStringUTF(std::to_string(entries[i].modified).c_str()));
    }

    LOGI("Indexed %zu files in %s", entries.size(), root.c_str());
    return result;
}

} // extern "C"
