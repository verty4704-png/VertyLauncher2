#include <jni.h>
#include <android/log.h>
#include <signal.h>
#include <unistd.h>
#include <string>

#define LOG_TAG "VertyCrash"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static struct sigaction oldHandlers[NSIG];

static void crashHandler(int sig, siginfo_t* info, void* context) {
    LOGE("Native crash caught: signal=%d, code=%d", sig, info->si_code);

    // Log stack trace info
    // In production, this would write to a crash file for later reporting

    // Call original handler
    if (oldHandlers[sig].sa_flags & SA_SIGINFO) {
        oldHandlers[sig].sa_sigaction(sig, info, context);
    } else {
        oldHandlers[sig].sa_handler(sig);
    }
}

extern "C" {

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_installCrashHandler(JNIEnv* env, jobject thiz) {
    struct sigaction sa;
    sa.sa_sigaction = crashHandler;
    sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);

    sigaction(SIGSEGV, &sa, &oldHandlers[SIGSEGV]);
    sigaction(SIGABRT, &sa, &oldHandlers[SIGABRT]);
    sigaction(SIGFPE, &sa, &oldHandlers[SIGFPE]);
    sigaction(SIGILL, &sa, &oldHandlers[SIGILL]);

    LOGI("Native crash handler installed");
}

} // extern "C"
