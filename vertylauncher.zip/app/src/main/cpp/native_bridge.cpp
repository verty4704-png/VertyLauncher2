#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <memory>
#include <thread>
#include <mutex>
#include <chrono>

#define LOG_TAG "VertyNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern "C" {

JNIEXPORT jstring JNICALL
Java_com_verty_launcher_core_native_NativeBridge_getNativeVersion(JNIEnv* env, jobject thiz) {
    return env->NewStringUTF("1.0.0-arm64-optimized");
}

JNIEXPORT jlong JNICALL
Java_com_verty_launcher_core_native_NativeBridge_getAvailableMemory(JNIEnv* env, jobject thiz) {
    struct sysinfo info;
    if (sysinfo(&info) == 0) {
        return static_cast<jlong>(info.freeram);
    }
    return 0;
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_trimMemory(JNIEnv* env, jobject thiz) {
    // Trigger Java GC from native side via reflection
    jclass runtimeClass = env->FindClass("java/lang/Runtime");
    jmethodID getRuntime = env->GetStaticMethodID(runtimeClass, "getRuntime", "()Ljava/lang/Runtime;");
    jobject runtime = env->CallStaticObjectMethod(runtimeClass, getRuntime);
    jmethodID gc = env->GetMethodID(runtimeClass, "gc", "()V");
    env->CallVoidMethod(runtime, gc);
    LOGI("Native memory trim triggered");
}

JNIEXPORT jboolean JNICALL
Java_com_verty_launcher_core_native_NativeBridge_isArm64Supported(JNIEnv* env, jobject thiz) {
    #if defined(__aarch64__)
        return JNI_TRUE;
    #else
        return JNI_FALSE;
    #endif
}

JNIEXPORT jlong JNICALL
Java_com_verty_launcher_core_native_NativeBridge_fastFileHash(JNIEnv* env, jobject thiz,
                                                                jstring path) {
    const char* cPath = env->GetStringUTFChars(path, nullptr);
    FILE* file = fopen(cPath, "rb");
    env->ReleaseStringUTFChars(path, cPath);

    if (!file) return -1;

    // Simple fast hash (FNV-1a)
    uint64_t hash = 0xcbf29ce484222325;
    unsigned char buffer[8192];
    size_t bytesRead;

    while ((bytesRead = fread(buffer, 1, sizeof(buffer), file)) > 0) {
        for (size_t i = 0; i < bytesRead; i++) {
            hash ^= buffer[i];
            hash *= 0x100000001b3;
        }
    }

    fclose(file);
    return static_cast<jlong>(hash);
}

} // extern "C"
