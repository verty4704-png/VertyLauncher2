#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <dlfcn.h>

#define LOG_TAG "VertyJVM"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern "C" {

// Optimized JVM argument builder for Android
JNIEXPORT jobjectArray JNICALL
Java_com_verty_launcher_core_native_NativeBridge_buildOptimizedJvmArgs(
    JNIEnv* env,
    jobject thiz,
    jint maxMemoryMb,
    jboolean useG1GC,
    jboolean useStringDeduplication,
    jboolean aggressiveOpts
) {
    std::vector<std::string> args;

    // Memory settings
    args.push_back("-Xms" + std::to_string(maxMemoryMb / 4) + "M");
    args.push_back("-Xmx" + std::to_string(maxMemoryMb) + "M");

    // GC optimization for Android
    if (useG1GC) {
        args.push_back("-XX:+UseG1GC");
        args.push_back("-XX:MaxGCPauseMillis=200");
        args.push_back("-XX:+UnlockExperimentalVMOptions");
        args.push_back("-XX:+UseContainerSupport");
    }

    if (useStringDeduplication) {
        args.push_back("-XX:+UseStringDeduplication");
    }

    // Android-specific optimizations
    args.push_back("-XX:+UseLargePages");
    args.push_back("-XX:+AlwaysActAsServerClassMachine");
    args.push_back("-XX:+UseNUMA");
    args.push_back("-Djava.awt.headless=true");
    args.push_back("-Dorg.lwjgl.system.allocator=system");
    args.push_back("-Dorg.lwjgl.opengl.display.allowSoftwareOpenGL=false");

    if (aggressiveOpts) {
        args.push_back("-XX:+UseFastAccessorMethods");
        args.push_back("-XX:+OptimizeStringConcat");
        args.push_back("-XX:+UseCompressedOops");
        args.push_back("-XX:+UseCompressedClassPointers");
    }

    // Create Java String array
    jobjectArray result = env->NewObjectArray(args.size(), env->FindClass("java/lang/String"), nullptr);
    for (size_t i = 0; i < args.size(); i++) {
        env->SetObjectArrayElement(result, i, env->NewStringUTF(args[i].c_str()));
    }

    return result;
}

} // extern "C"
