#include <jni.h>
#include <android/log.h>
#include <sys/mman.h>
#include <sys/resource.h>

#define LOG_TAG "VertyMem"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" {

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_setProcessPriority(
    JNIEnv* env,
    jobject thiz,
    jint priority
) {
    setpriority(PRIO_PROCESS, 0, priority);
}

JNIEXPORT void JNICALL
Java_com_verty_launcher_core_native_NativeBridge_adviseSequentialAccess(
    JNIEnv* env,
    jobject thiz,
    jstring path
) {
    const char* cPath = env->GetStringUTFChars(path, nullptr);
    // Advise kernel about sequential access pattern for faster asset loading
    // This is a hint - actual implementation would use madvise on mapped files
    LOGI("Sequential access advised for: %s", cPath);
    env->ReleaseStringUTFChars(path, cPath);
}

JNIEXPORT jlong JNICALL
Java_com_verty_launcher_core_native_NativeBridge_getNativeHeapSize(JNIEnv* env, jobject thiz) {
    struct rusage usage;
    if (getrusage(RUSAGE_SELF, &usage) == 0) {
        return usage.ru_maxrss * 1024L; // Convert KB to bytes
    }
    return 0;
}

} // extern "C"
