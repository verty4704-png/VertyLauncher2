# VertyLauncher ProGuard Rules
# Keep entry points
-keep public class com.verty.launcher.MainActivity { *; }
-keep public class com.verty.launcher.VertyApplication { *; }

# Keep Hilt generated classes
-keep class dagger.hilt.** { *; }
-keep class * extends dagger.hilt.internal.GeneratedComponent { *; }

# Keep serialization
-keepattributes *Annotation*, InnerClasses, Signature, Exceptions, SourceFile, LineNumberTable
-keepclassmembers class * {
    @kotlinx.serialization.Serializable <fields>;
}

# Keep Room entities
-keep class com.verty.launcher.data.local.entity.** { *; }

# Keep native methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Remove logging in release
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
}

# OkHttp
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**

# Retrofit
-dontwarn retrofit2.**
-keep class retrofit2.** { *; }

# Coil
-dontwarn coil.**

# Tink
-dontwarn com.google.crypto.tink.**
