pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://jitpack.io") }
        maven { url = uri("https://maven.fabricmc.net") }
        maven { url = uri("https://maven.minecraftforge.net") }
    }
}

rootProject.name = "VertyLauncher"

include(":app")
include(":core:common")
include(":core:native")
include(":feature:auth")
include(":feature:launcher")
include(":feature:mods")
include(":feature:downloads")
include(":feature:settings")
