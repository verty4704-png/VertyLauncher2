# VertyLauncher

**Next-Generation Android Minecraft Launcher**

[![Build](https://github.com/verty4704/vertylauncher/actions/workflows/build.yml/badge.svg)](https://github.com/verty4704/vertylauncher/actions)

## Overview

VertyLauncher is a premium Android Minecraft Java Edition launcher built with modern architecture, beautiful UI, and extreme performance optimization. Designed to outperform PojavLauncher, FoldCraftLauncher, and HMCL PE.

## Features

### Core
- Kotlin + MVVM + Clean Architecture
- Jetpack Compose UI with Material You
- Modular feature-based structure
- Hilt dependency injection
- Scoped Storage only (Android 10-15)

### Performance
- ARM64 native optimization via C++
- Fast file indexing (native)
- Optimized JVM argument builder
- Smart RAM allocation
- Lazy loading everywhere
- Coroutines + Flow

### UI/UX
- Glassmorphism + animated gradients
- 120fps transitions
- Dynamic blur effects
- AMOLED dark theme
- Responsive layouts (phone + tablet)
- Landscape support

### Minecraft Support
- Java Edition full support
- Fabric / Forge / NeoForge / Quilt
- Java 8 / 17 / 21 runtime management
- Vulkan / OpenGL renderer selection
- Shader support
- Modpack installer
- CurseForge / Modrinth integration

### Security
- Encrypted credential storage (Tink)
- Biometric lock support
- Secure token management
- No spyware / no trackers
- Sandbox for mods

## Architecture

```
app/
├── ui/              # Jetpack Compose screens & components
├── core/            # Business logic (security, download, launch)
├── data/            # Repository pattern implementation
├── domain/          # Models & use cases
├── service/         # Foreground services
└── di/              # Hilt modules

core/
├── common/          # Shared utilities
└── native/          # C++ JNI layer

feature/
├── auth/            # Account management
├── launcher/        # Instance & launch logic
├── mods/            # Mod management
├── downloads/       # Download manager UI
└── settings/        # Settings & preferences
```

## Build

```bash
# Debug build
./gradlew assembleDebug

# Release build
./gradlew assembleRelease

# Run tests
./gradlew test

# Code analysis
./gradlew detekt
```

## Requirements

- Android 10+ (API 29+)
- ARM64 device (arm64-v8a)
- 2GB+ RAM recommended
- OpenGL ES 3.2 or Vulkan

## License

MIT License - See [LICENSE](LICENSE) for details.

## Credits

Inspired by PojavLauncher, FoldCraftLauncher, and HMCL PE. Built to push Android Minecraft launching to the next level.
