# Security Guide

## Data Protection

1. **EncryptedSharedPreferences**: AES-256 SIV + GCM
2. **Tink Library**: Google's cryptographic library
3. **MasterKey**: Hardware-backed when available (TEE/StrongBox)
4. **No Plaintext**: All tokens, credentials encrypted
5. **Auto-lock**: Biometric prompt for sensitive operations

## Network Security

1. **Certificate Pinning**: Domain-specific trust anchors
2. **No Cleartext**: `usesCleartextTraffic="false"`
3. **DNS-over-HTTPS**: Prevents DNS hijacking
4. **User-Agent**: Identifies launcher version

## Scoped Storage

1. **App-private directories only**: `context.filesDir`, `context.cacheDir`
2. **No READ/WRITE_EXTERNAL_STORAGE**: Not requested
3. **FileProvider**: For sharing files with system
4. **No legacy paths**: No `/sdcard/` or `/storage/` hardcoding

## Sandboxing

1. **Process Isolation**: Minecraft runs in separate process
2. **Mod Sandbox**: Restricted file access for mods
3. **No Root Required**: All operations within app sandbox
4. **Runtime Validation**: Checks file integrity before execution

## Privacy

1. **Zero Analytics**: No trackers, no telemetry
2. **No Spyware**: No data collection beyond functional needs
3. **Open Source**: Full code auditable
4. **Minimal Permissions**: Only what's strictly necessary
