# VertyLauncher Privacy Policy

**Effective Date:** January 1, 2024

## Overview

VertyLauncher is committed to protecting your privacy. This policy explains what information we collect, how we use it, and your rights.

## Information We Collect

### Account Information
- **Microsoft/Xbox Login**: When you sign in with Microsoft, we store:
  - Your Minecraft username and UUID
  - Xbox User ID (XUID)
  - Authentication tokens (encrypted)

  This data is stored **only on your device** using Android's EncryptedSharedPreferences with hardware-backed encryption (AES-256).

### Offline Accounts
- **Username only**: For offline mode, we only store your chosen username. No passwords or personal data.

### Game Data
- **Instance configurations**: Minecraft version, mod lists, settings
- **Download cache**: Temporary files for game assets
- **Crash logs**: Anonymous crash reports (no personal data)

All game data is stored in your device's **app-private directory** (Scoped Storage) and is never transmitted to our servers.

## What We Do NOT Collect

- **Zero analytics**: No usage tracking, no telemetry
- **Zero advertising IDs**: No ad tracking
- **Zero device fingerprinting**: No unique device identification
- **Zero network monitoring**: We don't log your gameplay
- **No data transmission**: All data stays on your device

## Permissions

VertyLauncher requests only these permissions:

| Permission | Purpose | Required |
|-----------|---------|----------|
| `INTERNET` | Download Minecraft files, mods | Yes |
| `ACCESS_NETWORK_STATE` | Check connectivity | Yes |
| `POST_NOTIFICATIONS` | Download progress | No (Android 13+) |
| `FOREGROUND_SERVICE` | Background downloads | Yes |
| `VIBRATE` | Haptic feedback | No |

**We do NOT request:**
- Storage permissions (we use Scoped Storage)
- Location
- Camera
- Contacts
- Phone state

## Data Security

- **Encryption at rest**: All credentials encrypted with Tink (Google's cryptographic library)
- **Hardware-backed keys**: When available, uses Android Keystore/StrongBox
- **Biometric lock**: Optional fingerprint protection for account access
- **No cloud sync**: Your data never leaves your device
- **Secure network**: DNS-over-HTTPS, certificate pinning

## Third-Party Services

VertyLauncher communicates with these services **directly from your device**:

| Service | Data Sent | Purpose |
|---------|-----------|---------|
| Mojang/Microsoft | Authentication tokens | Minecraft login |
| CurseForge API | Search queries | Mod discovery |
| Modrinth API | Search queries | Mod discovery |
| Minecraft CDN | Version requests | Game file downloads |

We do not proxy, log, or modify these communications.

## Children's Privacy

VertyLauncher does not knowingly collect data from children under 13. If you are a parent and believe your child has provided personal information, contact us to have it removed.

## Changes to This Policy

We may update this policy. Changes will be posted in the app and on our GitHub repository.

## Contact

For privacy questions or data deletion requests:
- GitHub Issues: https://github.com/verty4704/vertylauncher/issues
- Email: privacy@vertylauncher.dev

## Open Source

VertyLauncher is fully open source. You can audit our code at:
https://github.com/verty4704/vertylauncher

**Last updated:** January 1, 2024
