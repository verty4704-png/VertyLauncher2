# Play Store Assets

## App Icon
- **Size**: 512x512px
- **Format**: PNG with transparency
- **Style**: Modern flat design with Minecraft diamond pickaxe + Android robot fusion
- **Colors**: Primary brand color (#4F5DFF) with Material You dynamic accents

## Feature Graphic (1024x500)
- **Title**: "VertyLauncher - Next-Gen Minecraft Launcher"
- **Subtitle**: "Fast. Beautiful. Premium."
- **Background**: Dark gradient with subtle animated mesh
- **Screenshots collage**: Dashboard, Instance Manager, Mod Browser
- **Badges**: "Android 10+", "ARM64 Optimized", "No Root"

## Screenshots (Phone - 16:9)
1. **Dashboard**: Glassmorphism cards, instance list, quick actions
2. **Instance Manager**: Create/edit instances with version/loader selection
3. **Mod Browser**: CurseForge/Modrinth integration with search
4. **Download Manager**: Progress bars, resume capability
5. **Settings**: Material You theming, performance options
6. **Account**: Microsoft/Xbox login, offline mode

## Screenshots (Tablet - 16:10)
- Same content as phone but with navigation rail and dual-pane layouts

## Promo Video (30 seconds)
1. 0-5s: Splash animation with logo
2. 5-15s: Dashboard showcase (smooth scrolling, glassmorphism)
3. 15-25s: Launch sequence (fast startup, game running)
4. 25-30s: Call to action "Download on Play Store"

## Short Description (80 chars)
"The fastest, most beautiful Minecraft Java launcher for Android."

## Full Description
```
VertyLauncher - Next-Generation Minecraft Launcher

The premium Minecraft Java Edition launcher for Android. Built for speed, 
designed for beauty, optimized for every device.

KEY FEATURES:

LAUNCH
- Launch Minecraft Java Edition on Android
- Support for all versions (1.6.4 to 1.21+)
- Automatic Java runtime management (8/17/21)
- Smart JVM optimization per device
- ARM64 native acceleration

MODDING
- Full Fabric, Forge, NeoForge, Quilt support
- Built-in mod browser (CurseForge + Modrinth)
- One-click mod installation
- Modpack installer
- Shader support

PERFORMANCE
- Ultra-fast cold start (<500ms)
- Smart RAM allocation
- Background asset downloading
- Resume-capable downloads
- Native file indexing

DESIGN
- Material You dynamic theming
- Glassmorphism UI
- 120fps animations
- AMOLED dark mode
- Tablet & landscape support

SECURITY
- Encrypted credential storage
- Biometric lock
- Scoped Storage only
- Zero trackers, zero analytics
- Open source

COMPATIBILITY
- Android 10 to Android 15
- ARM64 devices (arm64-v8a)
- No root required
- Redmi/MIUI optimized

VertyLauncher is open source and community-driven. Join us on GitHub!
```

## Content Rating
- **Category**: Games > Simulation
- **Content Rating**: Everyone 10+ (Fantasy Violence)
- **Ads**: No
- **In-app purchases**: No
- **Data collection**: None (device-only storage)
