# VertyLauncher Architecture

## Overview

VertyLauncher follows **Clean Architecture** with **MVVM** presentation pattern and **modular feature structure**.

## Layers

### 1. Presentation Layer (UI)
- **Jetpack Compose** for all screens
- **ViewModel** with Hilt injection
- **StateFlow** for reactive UI updates
- **Navigation Compose** for routing

### 2. Domain Layer
- **Models**: Pure Kotlin data classes (serializable)
- **Use Cases**: Business logic operations
- **Repository Interfaces**: Abstract data access

### 3. Data Layer
- **Repositories**: Concrete implementations
- **Local**: DataStore, Room, File system
- **Remote**: Retrofit + OkHttp APIs
- **Security**: EncryptedSharedPreferences + Tink

### 4. Core Layer
- **Native**: C++ JNI for performance-critical ops
- **Security**: Token management, encryption
- **Download**: Resume-capable download manager
- **Performance**: System monitoring, optimization

## Module Structure

```
app/              - Main application module
  ui/             - Compose screens, navigation, theme
  core/           - Security, download, launch, native
  data/           - Repositories, local/remote sources
  domain/         - Models, use cases
  service/        - Foreground services
  di/             - Hilt modules

core/common/      - Shared utilities across modules
core/native/      - C++ native code

feature/auth/     - Account management (MS/Xbox/Offline)
feature/launcher/ - Instance creation & launch
feature/mods/     - Mod browser & installer
feature/downloads/- Download queue UI
feature/settings/ - Preferences & configuration
```

## Dependency Direction

```
app -> feature/*
app -> core/*
feature/* -> core/common
feature/* -> core/native (optional)
All -> domain (models)
```

## Key Design Decisions

1. **No Fragments**: 100% Compose navigation
2. **No LiveData**: Only StateFlow/Flow
3. **Scoped Storage**: No external storage permissions
4. **ARM64 Only**: Optimized for modern devices
5. **Coroutines Everywhere**: No callbacks, no blocking
6. **Lazy Initialization**: Everything loads on-demand
7. **Native Acceleration**: File ops, memory, hashing in C++
