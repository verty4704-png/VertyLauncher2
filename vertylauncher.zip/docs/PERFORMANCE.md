# Performance Guide

## Startup Optimization

1. **Lazy DI**: Hilt components initialized on first use
2. **Splash Screen API**: Native Android 12+ splash
3. **Profile Installer**: Baseline profiles for hot paths
4. **No Heavy init in Application.onCreate**
5. **Native library loading**: Async on background thread

## Memory Optimization

1. **Smart RAM Allocation**: Auto-detects device RAM and sets optimal JVM heap
2. **Native Memory Trim**: JNI-triggered GC before launch
3. **Lazy Loading**: Images, data, UI all load on-demand
4. **Coroutine Scopes**: Proper lifecycle management
5. **LargeHeap**: Not used - we manage memory smartly

## Rendering Performance

1. **Compose Optimization**: 
   - `remember` for expensive calculations
   - `derivedStateOf` for filtered lists
   - `LazyColumn` with keys for instances
   - `immutable` collections where possible

2. **Animation**: 
   - Hardware-accelerated transitions
   - `animateFloatAsState` with spring physics
   - Reduced motion respect for accessibility

## Native Optimizations

1. **Fast File Indexing**: Recursive C++ directory scan
2. **FNV-1a Hashing**: Fast file integrity checks
3. **Sequential Access Hints**: Kernel madvise for assets
4. **ARM64 Assembly**: NEON-optimized where applicable
5. **Process Priority**: Background launcher, foreground game

## Network

1. **DNS-over-HTTPS**: Faster, more secure resolution
2. **Connection Pooling**: 64 max requests, 10 per host
3. **OkHttp Cache**: 50MB persistent cache
4. **Resume Support**: HTTP Range requests for downloads
5. **Parallel Downloads**: 6 concurrent with semaphore
