# LWJGL Android Bridge — Architecture Guide

## What is LWJGL?

LWJGL (Lightweight Java Game Library) is what Minecraft uses to:
- Talk to GPU (OpenGL)
- Create windows (GLFW)
- Play sound (OpenAL)
- Manage memory (Jemalloc)

**Problem**: LWJGL only supports Windows/Mac/Linux. It does NOT work on Android.

## What We Need to Do

### 1. Rebuild LWJGL Native Libraries for Android (ARM64)

Download LWJGL source and cross-compile for Android:

```bash
# LWJGL 3.3.2 source
# Target: arm64-v8a
# Compiler: Android NDK clang

# Libraries to build:
# - liblwjgl.so (core)
# - libglfw.so (windowing)
# - libopenal.so (audio)
# - libjemalloc.so (memory)
# - liblwjgl_stb.so (image loading)
# - liblwjgl_opengl.so (OpenGL bindings)
# - liblwjgl_vulkan.so (Vulkan bindings)
```

**PojavLauncher already did this work.** We can use their prebuilt libraries:
- https://github.com/PojavLauncherTeam/lwjgl3
- https://github.com/PojavLauncherTeam/android-openjdk-build-multiarch

### 2. Create Java "Fake" LWJGL Classes

Minecraft calls:
```java
GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
GLFW.glfwCreateWindow(800, 600, "Minecraft", 0, 0);
```

We provide our own `org.lwjgl.opengl.GL11` and `org.lwjgl.glfw.GLFW` that:
- **Redirect calls to our JNI bridge**
- **Never call real desktop LWJGL**

### 3. JNI Bridge (C++)

Our C++ code sits between Java and Android:

```cpp
// Java calls: GL11.glClear(mask)
// JNI receives this, translates to GLES call

extern "C" JNIEXPORT void JNICALL
Java_org_lwjgl_opengl_GL11_glClear(JNIEnv* env, jclass clazz, jint mask) {
    // Convert OpenGL constants to OpenGL ES constants
    int glesMask = 0;
    if (mask & GL_COLOR_BUFFER_BIT) glesMask |= GL_COLOR_BUFFER_BIT;
    if (mask & GL_DEPTH_BUFFER_BIT) glesMask |= GL_DEPTH_BUFFER_BIT;
    if (mask & GL_STENCIL_BUFFER_BIT) glesMask |= GL_STENCIL_BUFFER_BIT;

    // Call OpenGL ES
    glClear(glesMask);
}
```

### 4. GLFW → Android Surface Bridge

GLFW expects a desktop window. We fake it:

```cpp
// Java calls: GLFW.glfwCreateWindow(w, h, title, monitor, share)
// We create an Android Surface and return a fake window handle

JNIEXPORT jlong JNICALL
Java_org_lwjgl_glfw_GLFW_glfwCreateWindow(
    JNIEnv* env, jclass clazz,
    jint width, jint height,
    jstring title, jlong monitor, jlong share
) {
    // Don't create real window — use existing Android SurfaceView
    // Return a fake handle (pointer to our window struct)
    return reinterpret_cast<jlong>(&g_androidWindow);
}
```

### 5. Touch → Mouse/Keyboard Bridge

Android touch events must become LWJGL mouse events:

```cpp
// Android: onTouchEvent(MotionEvent)
// → JNI call to inject into GLFW input queue

void injectMouseMove(float x, float y) {
    g_mouseX = x;
    g_mouseY = y;
    // Call Java callback if registered
    if (g_mousePosCallback) {
        g_mousePosCallback(g_window, x, y);
    }
}

void injectMouseButton(int button, int action) {
    if (g_mouseButtonCallback) {
        g_mouseButtonCallback(g_window, button, action, 0);
    }
}
```

### 6. OpenGL → OpenGL ES Translation

Minecraft uses desktop OpenGL. Android has OpenGL ES.

**Key differences:**
| Desktop OpenGL | OpenGL ES | Solution |
|---|---|---|
| `glBegin/glEnd` | Not supported | Use VBOs |
| `glVertexPointer` | `glVertexAttribPointer` | Rewrite |
| Immediate mode | VBO only | Use gl4es or ANGLE |
| Fixed pipeline | Programmable pipeline | Shader conversion |

**Two approaches:**

**A) gl4es (easier)**
- Library that translates OpenGL → OpenGL ES automatically
- PojavLauncher uses this
- Some performance overhead

**B) ANGLE (better)**
- Google's library: OpenGL → Vulkan → OpenGL ES
- Better performance on modern devices
- More complex setup

**C) Native bridge (what we implement)**
- Direct translation in our JNI layer
- Fastest but most work
- We do common operations, fall back to gl4es for edge cases

## File Structure

```
cpp/
├── lwjgl_bridge.cpp          # Main JNI registration
├── glfw_android.cpp          # GLFW window/input fake
├── gl_bridge.cpp             # OpenGL → OpenGL ES translation
├── al_bridge.cpp             # OpenAL → AudioTrack translation
├── egl_context.cpp           # EGL context management
├── touch_input.cpp           # Touch → mouse injection
├── gl4es_loader.cpp          # gl4es integration (optional)
└── CMakeLists.txt            # Build all native libs

java/org/lwjgl/
├── opengl/
│   ├── GL11.java             # Fake GL11 class
│   ├── GL12.java             # Fake GL12 class
│   ├── GL13.java             # Fake GL13 class
│   ├── GL14.java             # Fake GL14 class
│   ├── GL15.java             # Fake GL15 class
│   ├── GL20.java             # Fake GL20 class
│   ├── GL21.java             # Fake GL21 class
│   ├── GL30.java             # Fake GL30 class
│   └── GLCapabilities.java   # Capabilities check
├── glfw/
│   ├── GLFW.java             # Fake GLFW class
│   ├── GLFWKeyCallback.java  # Key callback
│   ├── GLFWMouseButtonCallback.java
│   ├── GLFWCursorPosCallback.java
│   └── GLFWWindowSizeCallback.java
└── system/
    ├── MemoryUtil.java       # Memory management
    └── Configuration.java    # LWJGL config
```

## Build Process

```bash
# 1. Download LWJGL Android libs from PojavLauncher
wget https://github.com/PojavLauncherTeam/lwjgl3/releases/download/3.3.2/lwjgl-android-arm64.zip

# 2. Extract to app/src/main/jniLibs/arm64-v8a/
unzip lwjgl-android-arm64.zip -d app/src/main/jniLibs/arm64-v8a/

# 3. Build our bridge
./gradlew externalNativeBuildRelease

# 4. Package everything into APK
./gradlew assembleRelease
```

## Runtime Flow

```
1. User clicks "Play" on instance
2. LaunchService starts
3. LaunchService creates SurfaceView (game window)
4. LaunchService starts JVM with our fake LWJGL classes
5. Minecraft loads, calls GL11.gl*, GLFW.*
6. Our fake classes redirect to JNI bridge
7. JNI bridge calls Android GLES / SurfaceView
8. Game renders!
```

## Key Challenges

1. **Shader compatibility**: Minecraft shaders use desktop GLSL. Need `#version` conversion.
2. **VBO vs immediate mode**: Old Minecraft versions use `glBegin/glEnd`. Must convert to VBOs.
3. **Multi-touch**: Android multi-touch → single mouse + keyboard emulation.
4. **Performance**: Translation layer adds overhead. Need ARM64 optimization.
5. **Compatibility**: Different Minecraft versions need different LWJGL versions (2.9.4 vs 3.x).

## Our Approach vs PojavLauncher

| Aspect | PojavLauncher | VertyLauncher |
|---|---|---|
| LWJGL version | 3.2.3 / 2.9.4 | 3.3.2 (latest) |
| GL translation | gl4es only | gl4es + native bridge |
| Input | Basic touch | Multi-touch + gesture support |
| Audio | OpenAL soft | OpenAL + low-latency AudioTrack |
| Optimization | Generic ARM | ARM64 NEON optimized |
| Code quality | Mixed Java/C | Clean C++ with CMake |

## Next Steps

1. **Download prebuilt LWJGL Android libs** from PojavLauncher releases
2. **Create fake Java LWJGL classes** (stub implementations)
3. **Implement JNI bridge** for most-used OpenGL functions
4. **Test with Minecraft 1.16.5** (stable LWJGL 3 version)
5. **Add gl4es fallback** for unsupported OpenGL features
6. **Optimize touch input** for gameplay comfort
